//
//  WelfareViewController.h
//  萤石运动3
//
//  Created by Winner Zhu on 2016/11/22.
//  Copyright © 2016年 Winner Zhu. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "NavHeadTitleView.h"

@class Ganhuo;


@interface WelfareViewController : UIViewController<UICollectionViewDelegate,UICollectionViewDelegateFlowLayout,UICollectionViewDataSource>{
    

    NSArray *theArrayForError;    
    NSArray *theArrayForResults;
    
    UIRefreshControl *refreshControl;
    BOOL isLoading;
    
    int lastContentOffset;
    
}


@property (nonatomic,strong) NSMutableArray *allOFCellArray;   //存储所有CollectionViewCell数据

@property (nonatomic,strong) NSMutableArray *cellArrayBeUsedEmum;   //用于枚举过程的数组,暂时存储cell

@property (nonatomic,strong) UICollectionView *welfareCollectionView;

@property (nonatomic,strong) NavHeadTitleView *navView;

@property (nonatomic,assign) NSInteger addingNum;

@property (nonatomic,assign) NSInteger difference;

@property (nonatomic,strong) NSString *resendRequestUrl;

@property (nonatomic,assign) BOOL scrollDirectionUpDown;  // yes:鼠标向上移动(上) // no:鼠标向下移动(下)

@property (nonatomic,assign) BOOL sendRequestAgainOrNo;



@end
