
//
//  WelfareViewController.m
//  萤石运动3
//
//  Created by Winner Zhu on 2016/11/22.
//  Copyright © 2016年 Winner Zhu. All rights reserved.
//

#import "WelfareViewController.h"
#import "CCPNetworking.h"
#import "Ganhuo.h"
#import "UIImageView+WebCache.h"
#import "OneOFWelfareViewCell.h" //#import "WelfareCollectionViewCell.h"
#import "NavHeadTitleView.h"
#import "ShowMeinvPopUpView.h"
#import "AlertPopUpView.h"

#define DoveGrayColor [UIColor colorWithRed:113.0/255.0 green:113.0/255.0 blue:113.0/255.0 alpha:255.0/255.0]
#define TheDeviceWidth ([UIScreen mainScreen].bounds.size.width)
#define TheDeviceHeight ([UIScreen mainScreen].bounds.size.height)
#define TheColletionViewCellSquareSize (TheDeviceWidth - 20)/2 //正方形cell 每个cell距离两边10点(20/2)
#define AnyColor(r,g,b,a) [UIColor colorWithRed:(r)/255.0 green:(g)/255.0 blue:(b)/255.0 alpha:(a)]
#define TheHeightOFcustomNavBar 64
#define TheScrollThreshold 70
#define fullScreen CGRectMake(0,0, TheDeviceWidth, TheDeviceHeight)



@implementation WelfareViewController

static NSString *const cellId = @"cellId";       //cellId use for coding
//static NSString *const cellIdd = @"cellIdd";     //cellIdd use for .xib


- (void)viewDidLoad {
    
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    //0.set navagaionBar Title 考虑是否自定义navagaionBar
    self.navigationController.navigationBarHidden = YES;
    
    //1.创建UICollectionView
    [self creatCollectionView];
    
    //2.网络访问
    [self sendRequest];
    
    //3.创建数组实例(公共化)
    _allOFCellArray = [[NSMutableArray alloc]init];
    
    //4.创建自定义UINavigationBar
    [self creatNavigationBar];
    
    //5.设置 BOOL sendRequestAgainOrNo 初始状态
    _sendRequestAgainOrNo = NO;
    
    
}




-(void)creatCollectionView{
 
    
    if (_welfareCollectionView == nil) {
        
        
        //1.创建布局类
        UICollectionViewFlowLayout *welfareFlowLayout = [[UICollectionViewFlowLayout alloc]init];
        
        //定义每个UICollectionCell大小  还有个估计大小的方法estimateSize
        welfareFlowLayout.itemSize=CGSizeMake(TheColletionViewCellSquareSize ,TheColletionViewCellSquareSize);
        
        //定义每个UICollectionViewCell的横向间距 [分明是纵向]
        welfareFlowLayout.minimumLineSpacing = 5;
        
        //定义每个UICollectionViewCell的纵向间距 [分明是横向]
        welfareFlowLayout.minimumInteritemSpacing = 5;
        
        //定义每个UICollectionViewCell的边距  //这个其实可以不设,我们在cell.xib中已经设了constrains = 2;
        welfareFlowLayout.sectionInset = UIEdgeInsetsMake(30, 5, 5, 5);
        //添加自定义导航后,Make(30, 5, 5, 5);与HomePageViewController中一致
        
        //定义UICollectionView滑动方向 [默认竖直滚动]
        //welfareFlowLayout.scrollDirection = UICollectionViewScrollDirectionVertical;
        
        
        //2.创建UICollectionView
        _welfareCollectionView = [[UICollectionView alloc]initWithFrame:CGRectMake(0, 20, TheDeviceWidth, TheDeviceHeight) collectionViewLayout:welfareFlowLayout];  //custom make(0,44);
        
        _welfareCollectionView.delegate = self;
        _welfareCollectionView.dataSource = self;
        _welfareCollectionView.backgroundColor = [UIColor whiteColor];
        
        
        //自适应大小
        _welfareCollectionView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
        
        
        //3.注册cell以及ReusableView  // ※ registerClass:[OneOFWelfareViewCell class]
        [_welfareCollectionView registerClass:[OneOFWelfareViewCell class] forCellWithReuseIdentifier:cellId];
        
        
    }
    
    [self.view addSubview:_welfareCollectionView];
    
    
    
    //add UIRefreshControl
    refreshControl = [[UIRefreshControl alloc]init];
    [_welfareCollectionView addSubview:refreshControl];
    refreshControl.tintColor = DoveGrayColor;
    
    [refreshControl addTarget:self action:@selector(refresh) forControlEvents:UIControlEventValueChanged];
    [[refreshControl.subviews objectAtIndex:0]setFrame:CGRectMake(0, 5, 0, 0)];
    //这样设置frame后刷新控件不会显示在画面中,隐形刷新操作
    
}


#pragma mark 刷新控件执行方法
-(void)refresh{
    
    if ((isLoading)) {
        
        [refreshControl endRefreshing];
        return;
    }
    
    isLoading = YES;
    [self sendRequest];
    [refreshControl endRefreshing];
    isLoading = NO;
    
}


#pragma mark - 返回cell内容

-(UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(nonnull NSIndexPath *)indexPath{
    
    //创建cell with .xib
    OneOFWelfareViewCell *newCell = [collectionView dequeueReusableCellWithReuseIdentifier:cellId forIndexPath:indexPath];
    Ganhuo *ganhuoIncellFor = [[Ganhuo alloc]init];
    ganhuoIncellFor = self.allOFCellArray [indexPath.item];
    NSURL *girlUrl = [NSURL URLWithString:ganhuoIncellFor.url];
    [newCell.welfareImageView sd_setImageWithURL:girlUrl];
    
    
    //二次网络请求
    _difference = self.allOFCellArray.count - indexPath.item;
    if (_difference == 16 && _scrollDirectionUpDown ==YES) {
        
        [self sendRequestAgain];
    }
    
    return  newCell;
    
}


#pragma mark - 选择一个cell时触发
-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    
    
    ShowMeinvPopUpView *popUpView = [[ShowMeinvPopUpView alloc]initWithFrame:self.view.bounds];
    popUpView.ganhuoForImage = _allOFCellArray[indexPath.item];
    
    
    [popUpView showPopUpViewAnimate:YES];
    
}


#pragma mark - 定义展示的cell个数
-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    
    return [_allOFCellArray count];
}


#pragma mark - 定义展示的section的个数
-(NSInteger )numberOfSectionsInCollectionView:(UICollectionView *)collectionView{
    
    return 1;
    
}



#pragma mark - 网络请求和数据加载
#pragma mark - 数据加载方法
-(void)loadData:(NSData *)data{
    
    //1.创建数组实例
    _cellArrayBeUsedEmum = [[NSMutableArray alloc]init];
    
    
    //2.JSON序列化实例化
    /*json序列化
     *option = 0,返回NSDictionary或者NSarray
     */
    NSError *error;
    //将对象序列化为字典
    NSDictionary *totalDic = [NSJSONSerialization JSONObjectWithData:data options:0 error:&error];
    theArrayForResults = (NSArray *)totalDic[@"results"];
    
    
    //3.枚举数组theArrayForResults中的item
    for (NSDictionary *ganhuoFrWelfare in theArrayForResults  ) {
    
        Ganhuo *ganhuoForImage = [[Ganhuo alloc]init];
        [ganhuoForImage setValuesForKeysWithDictionary:ganhuoFrWelfare];
        
        [_cellArrayBeUsedEmum addObject:ganhuoForImage];
        
    }
    
    
    //4.将枚举得到的ganhuo(数组)添加到枚举后的数组
    
    if (_sendRequestAgainOrNo ==YES) {
        [_allOFCellArray addObjectsFromArray:_cellArrayBeUsedEmum];
        
    }else{
        
        _allOFCellArray = _cellArrayBeUsedEmum;
    }
    
    
    //5.加载数据完成后刷新collectionView
    //[_welfareCollectionView reloadData];
    

}


#pragma mark - 网络请求方法
-(void)sendRequest{
    
    
    /*
     *注意对于url中的中文是无法解析的，需要进行url编码(指定编码类型为UTF-8),
     *另外注意url解码使用stringByRemovingPercentEncoding方法
     */
    
    //1.编码string,创建URL【创建URL】
    
    NSString *finalUrlStr ;
    if (_sendRequestAgainOrNo == YES) {
        
        self.resendRequestUrl = [self.resendRequestUrl stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
        finalUrlStr = self.resendRequestUrl;
        
    }else{
        
        NSString *originalUrlStr = @"http://gank.io/api/data/福利/40/1"; //每次获取25个妹子
        originalUrlStr = [originalUrlStr stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
        finalUrlStr = originalUrlStr;
        
    }
    NSURL *url = [NSURL URLWithString:finalUrlStr];
    
    
    //2.创建可变请求,设置请求方式为GET【创建请求】
    NSMutableURLRequest *requestForWelfare = [[NSMutableURLRequest alloc]initWithURL:url cachePolicy:NSURLRequestUseProtocolCachePolicy  timeoutInterval:5.0f];
    [requestForWelfare setHTTPMethod:@"GET"];
    
    
    //3.创建可变请求【创建链接】
    [NSURLConnection sendAsynchronousRequest:requestForWelfare queue:[NSOperationQueue mainQueue] completionHandler:^(NSURLResponse *respone,NSData *data,NSError *error ){
        
        if (!error) {
            
            [self loadData:data];
            [_welfareCollectionView reloadData];
            
        }else{            
            AlertPopUpView *alertView = [[AlertPopUpView alloc]initWithFrame:fullScreen alertStr:@"请求超时啦"];
            [alertView showPopUpViewAnimate:YES];
        }
    }];
    
    /*创建请求
     cachePolicy:缓存策略
     a.NSURLRequestUseProtocolCachePolicy 协议缓存，根据response中的Cache-Control字段判断缓存是否有效，如果缓存有效则使用缓存数据否则重新从服务器请求
     b.NSURLRequestReloadIgnoringLocalCacheData 不使用缓存，直接请求新数据
     c.NSURLRequestReloadIgnoringCacheData 等同于 SURLRequestReloadIgnoringLocalCacheData
     d.NSURLRequestReturnCacheDataElseLoad 直接使用缓存数据不管是否有效，没有缓存则重新请求
     eNSURLRequestReturnCacheDataDontLoad 直接使用缓存数据不管是否有效，没有缓存数据则失败
     timeoutInterval:超时时间设置（默认60s）
     */
    
    
    /*
    //3.0创建会话(session)(这里使用了一个全局会话)并且启动任务
    NSURLSession *session = [NSURLSession sharedSession];
    //从会话(session)创建任务
    NSURLSessionDataTask *dataTask  = [session dataTaskWithRequest:requestForWelfare completionHandler:^( NSData *data ,NSURLResponse *response,NSError *error  ){
        if ( !error) {
            
            //1.加载数据(将下载来的数据data推出)
            [self loadData:data];
            
            //2.刷新视图
            [_welfareCollectionView reloadData];
            
            
        }else{
            
            NSLog(@"error is : %@",error.localizedDescription);
        }
        
    }];
    //3.1恢复线程,启动任务
    [dataTask resume];
    */

    
}



#pragma mark - 自定义导航栏及其变换
#pragma mark - 创建导航栏
-(void)creatNavigationBar{
    
    
    self.navView = [[NavHeadTitleView alloc]initWithFrame:CGRectMake(0, 0, TheDeviceWidth, TheHeightOFcustomNavBar )];
    self.navView.nameTitle = @"福利拿去";
    //self.navView.color =  AnyColor(87, 173, 104, 1);
    //self.navView.delegate = self;
    //[UIApplication sharedApplication].statusBarStyle = UIStatusBarStyleDefault;
    
    [self.view addSubview:self.navView];
    
}


#pragma mark 滚动视图将要被拖拽
-(void)scrollViewWillBeginDragging:(UIScrollView *)scrollView{
    
    lastContentOffset = scrollView.contentOffset.y;
}


#pragma mark - UICollectionView下拉后CustomNavigationBar效果
-(void)scrollViewDidScroll:(UIScrollView *)scrollView{
    
    //1.int 纵向偏移量
    int contentOffsetY = scrollView.contentOffset.y;
    int currentContentOffsetY = scrollView.contentOffset.y;
    
    //2.通过scrollView contentOffset设置navigationBar的状态
    if (contentOffsetY <= TheScrollThreshold ) { // TheScrollThreshold 70
        //正在向上推≈回到顶部:不透明,有颜色;有title
        
        self.navView.headBgview.alpha = 1;
        self.navView.color = [UIColor blackColor];
        self.navView.nameTitle = @"福利拿去";
        self.navView.rightImageView = @"";
        self.navView.backTitleImage = @"";
        
        //隐藏黑线
        [self.navigationController.navigationBar setShadowImage:[UIImage new]];
        //状态栏字体黑色
        [UIApplication sharedApplication].statusBarStyle = UIStatusBarStyleDefault;
        
    }else{
        //向上推送越过阈值:透明,无色;无title
        
        self.navView.headBgview.alpha = contentOffsetY/MAXFLOAT; // 0.3;//contentOffsety / 170;
        self.navView.color = [UIColor clearColor];
        self.navView.nameTitle = nil;
        self.navView.rightImageView = @"";
        self.navView.backTitleImage = @"";
        
        //状态栏字体白色
        //[UIApplication sharedApplication].statusBarStyle = UIStatusBarStyleLightContent;
        
    }
    
    //3.判断滚动状态
    if (currentContentOffsetY > lastContentOffset && currentContentOffsetY >= 50) {
        _scrollDirectionUpDown = YES;
        
    }else{
        _scrollDirectionUpDown = NO;
    }

    
}


#pragma mark - 在此发送网络请求
-(void)sendRequestAgain{
    
    //1.累加
    if (self.addingNum == 0) {
        self.addingNum = 1;
    }
    self.addingNum += 1;

    
    //2.生成resendRequestUrl  //http://gank.io/api/data/福利/40/1
    NSString *part1 = @"http://gank.io/api/data/福利/40/";
    NSString *part2 = [NSString stringWithFormat:@"%ld",(long)_addingNum];
    NSString *total = [part1 stringByAppendingString:part2];
    _resendRequestUrl = total;
    
    
    //3.设置sendRequestAgainOrNo 为 YES;
    //sendRequestAgainOrNo页面初始时为 NO,此处设为YES后,在该页面VC存在的周期一直为YES
    _sendRequestAgainOrNo = YES;
    
    
    //4.发送请求
    [self sendRequest];
    
}





- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
