//
//  OneOFGanhuoTableViewCell.m
//  萤石运动3
//
//  Created by Winner Zhu on 16/8/17.
//  Copyright © 2016年 Winner Zhu. All rights reserved.
//

#import "OneOFGanhuoTableViewCell.h"
#import "Ganhuo.h"
#import "Masonry.h"

#define AnyColor(r,g,b) [UIColor colorWithHue:r/255.0 saturation:g/255.0 brightness:b/255.0 alpha:1]
#define TableViewCellBackgroundColor AnyColor(251,251,251)
#define TableViewCellLightGrayColor AnyColor(120,120,120)
#define TableViewCellDoveGrayColor [UIColor colorWithRed:113.0/255.0 green:113.0/255.0 blue:113.0/255.0 alpha:255.0/255.0]

#define OneOFGanhuoTabCellDescriptionFontSize 14    //description字体
#define OneOFGanhuoTabCellVerticalControlSpacing 15  //纵向控件间距
#define OneOFGanhuoTabCellHorizontalControlSpacing 15  //横向控件间距

#define TheDeviceWidth ([UIScreen mainScreen].bounds.size.width)
#define TheDeviceHeight ([UIScreen mainScreen].bounds.size.height)



@implementation OneOFGanhuoTableViewCell

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        
        [self initSubView];
    }
    
    return self;
}



#pragma mark 初始化视图

-(void)initSubView{

    _DescriptionLabel = [[UILabel alloc]init];
    _DescriptionLabel.textColor = TableViewCellDoveGrayColor;
    _DescriptionLabel.font = [UIFont systemFontOfSize:OneOFGanhuoTabCellDescriptionFontSize];
    _DescriptionLabel.numberOfLines = 0;
    
    UIView *lineView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, TheDeviceWidth, 0.5)];
    lineView.backgroundColor = [UIColor colorWithRed:238.0/255.0 green:238.0/255.0 blue:238.0/255.0 alpha:255.0/255.0];//[UIColor lightGrayColor];
    
    [self.contentView addSubview:lineView];
    [self.contentView addSubview:_DescriptionLabel];

    
}




#pragma mark 设置干货
-(void)setGanhuo:(Ganhuo *)ganhuo{

    //设置DescriptionLabel位置

    CGFloat DescriptionLabelX = OneOFGanhuoTabCellHorizontalControlSpacing;
    //此处与cell宽度对应;应该等于横向间距
    
    CGFloat DescriptionLabelY = OneOFGanhuoTabCellVerticalControlSpacing;
    //此处与cell高度对应;应该等于纵向间距
    
    CGFloat DescriptionWidth = TheDeviceWidth - OneOFGanhuoTabCellHorizontalControlSpacing*2;
    
     _DescriptionLabel.text = ganhuo.desc;
     
    CGSize DescriptionLabelSize = [ganhuo.desc boundingRectWithSize:CGSizeMake(DescriptionWidth, MAXFLOAT) options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName: [UIFont systemFontOfSize:OneOFGanhuoTabCellDescriptionFontSize]} context:nil].size;
    
    CGRect DescriptionLabelRect = CGRectMake(DescriptionLabelX, DescriptionLabelY, DescriptionLabelSize.width , DescriptionLabelSize.height);
    _DescriptionLabel.frame = DescriptionLabelRect;
    
    _Height = CGRectGetMaxY(_DescriptionLabel.frame) + OneOFGanhuoTabCellVerticalControlSpacing;
    
    
}


#pragma mark 重写选择事件,取消选中
-(void)setSelected:(BOOL)selected animated:(BOOL)animated{
    
    //[super setSelected:selected animated:animated];
    
}



@end
