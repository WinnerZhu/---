//
//  SortAndFavViewController.m
//  萤石运动3
//
//  Created by Winner Zhu on 2016/11/13.
//  Copyright © 2016年 Winner Zhu. All rights reserved.
//

#import "SortAndFavViewController.h"
#import "FavouriteViewController.h"
#import "SortViewController.h"
#import "SegmentViewController.h"


#define TheDeviceWidth ([UIScreen mainScreen].bounds.size.width)
#define TheDeviceHeight ([UIScreen mainScreen].bounds.size.height)

#define UISegmentedNavigationBarHeight 64

#define AnyColor(r,g,b) [UIColor colorWithHue:r/255.0 saturation:g/255.0 brightness:b/255.0 alpha:1]
#define separaterColor AnyColor(200,199,204)
#define PressColor AnyColor(64,64,64)
#define NavigationBarFontSize 17
#define TheFontOfSizeInSegment NavigationBarFontSize



@interface SortAndFavViewController ()<clickButtonDelegate>{

   
    
}


#pragma mark - 分段控制器的下标标识符
@property (nonatomic,assign) NSInteger *page;

@property (nonatomic,strong) SegmentViewController *SegVC;

@property (nonatomic,strong) FavouriteViewController *FavViewController;


@end


@implementation SortAndFavViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    [self setUpUISegmentedNavigationBar];
    [self addSegmentViewController];
    
    
}

-(void)viewWillAppear:(BOOL)animated{
    
//    [self setUpUISegmentedNavigationBar];
//    [self addSegmentViewController];
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


#pragma mark - Set UISegmentedControl in UINavigationBar
-(void)setUpUISegmentedNavigationBar{
    
    
    //0.隐藏navigationBar
    self.navigationController.navigationBar.hidden = YES;
    
    
    //1.UIView - BackgroundView
    UIView *navView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, TheDeviceWidth, UISegmentedNavigationBarHeight )]; //UISegmentedNavigationBarHeight  = 64
    navView.backgroundColor = [UIColor whiteColor];
    //[UIColor colorWithRed:58.0/255.0 green:190.0/255.0 blue:160.0/255.0 alpha:255.0/255.0];
    [self.view addSubview:navView];
    
    
    //2.UISegmentedControl 中文名:文段控制器
    UISegmentedControl *segment = [[UISegmentedControl alloc]initWithItems:@[@"要哪类干货?",@"我稀饭你!"]];
    segment.frame = CGRectMake(36, 25, TheDeviceWidth - 36*2, 30);
    segment.tintColor= [UIColor colorWithRed:64.0/255.0 green:64.0/255.0 blue:64.0/255.0 alpha:255.0/255.0]; //被按压的按钮的颜色;
    //[UIColor colorWithRed:39.0/255.0 green:143.0/255.0 blue:119.0/255.0 alpha:255.0/255.0];
    segment.selectedSegmentIndex = 0;

    [segment setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys:[UIFont boldSystemFontOfSize:TheFontOfSizeInSegment],NSFontAttributeName,PressColor,NSForegroundColorAttributeName, nil]  forState:UIControlStateNormal];
    
    [segment setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys:[UIFont boldSystemFontOfSize:TheFontOfSizeInSegment],NSFontAttributeName,PressColor,NSForegroundColorAttributeName, nil] forState:UIControlStateHighlighted];
    
    [navView addSubview:segment];
    //[self.view bringSubviewToFront:navView];
    
    [segment addTarget:self action:@selector(segmentChangePage:) forControlEvents:UIControlEventValueChanged];
    
    
    //3.添加底线
    UIView*navLine=
    [[UIView alloc]initWithFrame:CGRectMake(0,UISegmentedNavigationBarHeight-0.5,TheDeviceWidth,0.5)];
    navLine.backgroundColor = [UIColor lightGrayColor];

    [navView addSubview:navLine];
    
    
    
}


-(void)segmentChangePage:(UISegmentedControl *)sec{
    
    NSInteger index = sec.selectedSegmentIndex;
    
    if (index == 0) {
        _page = 0;
        
        [_FavViewController.view removeFromSuperview];//a中先删除b
        [self addSegmentViewController];
        
        
    } else {
      
        _page = 1;
        [_SegVC.view removeFromSuperview];
        
        _FavViewController = [[FavouriteViewController alloc]init];
        _FavViewController.view.frame = CGRectMake(0, UISegmentedNavigationBarHeight , TheDeviceWidth, TheDeviceHeight - 44-49);
        [self.view addSubview:_FavViewController.view];
        [self.view sendSubviewToBack:_FavViewController.view];
        //将自己添加到最底层,再向上移动35点(FavouriteViewController.m)中设置
        [self addChildViewController:_FavViewController];
        
        
    }
}



#pragma marl - Set SegmentViewController
-(void)addSegmentViewController{
    
    
    //0.init
    _SegVC = [[SegmentViewController alloc]init];
    _SegVC.view.frame = CGRectMake(0, UISegmentedNavigationBarHeight, TheDeviceWidth, TheDeviceHeight - 44 - 49);
    [self.view addSubview:_SegVC.view];
    
    
    //1.titleArray for SegmentViewController
    NSArray *titleArray = @[@"iOS",@"Android",@"前端",@"休息视频", @"拓展资源"];
    _SegVC.titleArray = titleArray;
    
    
    //2.Set subViewController in SegmentViewController 多线程加载
    //2.1生成数组
    NSMutableArray *controlArray = [[NSMutableArray alloc]init];
    //2.2创建一个串行队列
    /*参数1:队列名称
     *参数2:队列类型
     */
    dispatch_queue_t serialQueue = dispatch_queue_create("myThreadQueue1", DISPATCH_QUEUE_SERIAL);
    //2.3创建数组元素并添加;创建多个线程用于填充图片
    for (int i = 0; i < _SegVC.titleArray.count; i++) {

        /*
        SortViewController *SortVc = [[SortViewController alloc]initWithIndex:i title:titleArray[i]];
        [controlArray addObject:SortVc];
        */
        
        ///*
        //异步执行队列任务
        dispatch_async(serialQueue, ^{
        
            SortViewController *SortVc = [[SortViewController alloc]initWithIndex:i title:titleArray[i]];
            [controlArray addObject:SortVc];
        });
    }
    _SegVC.subViewControllers = controlArray;
    

    //3.Set other property for SegVC
    _SegVC.delegate = self;
    _SegVC.titleSelectedColor = [UIColor redColor];
    [_SegVC initSegment];
    [_SegVC addParentController:self];
    
    
}




//1.代理的方法在此页实现按钮的效果
//2.实现titleArray公有化,addSegmentViewController中实现 _SegVC.titleArray = titleArray;
//3.实现controlArray公有化,点击按钮后创建SortViewController *SortVc,并添加到controlArray;与1.联动。

/*
#pragma mark - SegmentViewController 代理方法
-(void)clickButtonOutsideSegViewControllerIndex:(NSInteger)index{
    
    //1.进入
    //2.得到的数是几
    NSLog(@"%ld",(long)index);

}
*/




/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
