//
//  GanhuoGroup.m
//  萤石运动3
//
//  Created by Winner Zhu on 16/8/30.
//  Copyright © 2016年 Winner Zhu. All rights reserved.
//

#import "GanhuoGroup.h"

@implementation GanhuoGroup




#pragma mark 带参数构造函数
-(GanhuoGroup *)initWithGroupname:(NSString *)groupname andGanhuos:(NSMutableArray *)ganhuos{
    
    if (self = [super init]) {
        
        self.groupname = groupname;
        self.ganhuos = ganhuos;
        
    }
    return self;
    
}

#pragma mark 静态初始化方法
+(GanhuoGroup *)initWithGroupname:(NSString *)groupname andGanhuos:(NSMutableArray *)ganhuos{
    
    GanhuoGroup *ganhuogroup = [[GanhuoGroup alloc]initWithGroupname:groupname andGanhuos:ganhuos];
    return ganhuogroup;
    
}











@end
