//
//  ShowGanhuoViewController.h
//  萤石运动3
//
//  Created by Winner Zhu on 16/8/31.
//  Copyright © 2016年 Winner Zhu. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Ganhuo.h"

#import "NJKWebViewProgress.h"  //浏览器WebView进度条
#import "NJKWebViewProgressView.h"

#import "BQLDBTool.h"
#import "BQLElseTool.h"

@class FavouriteGanhuo;


@interface ShowGanhuoViewController : UIViewController<UIWebViewDelegate,NJKWebViewProgressDelegate>{
    
    //1.浏览器
    UIWebView *webView;
    
    //2.导航栏
    UINavigationBar *navigationBar;
    UIBarButtonItem *barButtonNaviBack;
    UIBarButtonItem *barButtonNaviReload;
    UINavigationItem *navigationItem;
    
    //3.工具栏
    UIToolbar *toolBar;
    UIBarButtonItem *barButtonToolGoBack;
    UIBarButtonItem *barButtonToolGoForward;
    UIBarButtonItem *barButtonToolShare;
    UIBarButtonItem *barButtonToolFavorite;
    
    //4.浏览器WebView进度条
    NJKWebViewProgress *webViewProgressProxy;
    NJKWebViewProgressView *webViewProgressView;
    
    //5.FMDB
    BQLDBTool *Tool;
    
}


#pragma mark 定义 干货 model
@property (nonatomic, strong) Ganhuo *ganhuo;

#pragma mark 定义 收藏的干货 
@property (nonatomic,strong) FavouriteGanhuo *FavouriteGanhuoModel;

#pragma mark 定义 收藏的干货用于网络访问
@property (nonatomic,strong) FavouriteGanhuo *FavGanhuoForNetw;

#pragma mark 定义 Title of ShowGanhuoViewController
@property (nonatomic,strong) NSString *TitleOFViewController;

#pragma mark 定义 Url for request
@property (nonatomic,strong) NSString *UrlFORRequest;


@end
