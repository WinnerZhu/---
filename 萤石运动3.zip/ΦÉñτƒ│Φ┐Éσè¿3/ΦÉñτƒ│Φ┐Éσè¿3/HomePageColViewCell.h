//
//  HomePageColViewCell.h
//  萤石运动3
//
//  Created by Winner Zhu on 2016/12/1.
//  Copyright © 2016年 Winner Zhu. All rights reserved.
//


@class CellModel;
#import <UIKit/UIKit.h>



@interface HomePageColViewCell : UICollectionViewCell

#pragma mark CellModel
@property (nonatomic,strong) CellModel *cellModel;

@property (nonatomic,weak) IBOutlet UILabel *dateL;

@property (nonatomic,weak) IBOutlet UILabel *titleL0;

@property (nonatomic,weak) IBOutlet UILabel *titleL1;

@property (nonatomic,weak) IBOutlet UILabel *titleL2;

@property (nonatomic,weak) IBOutlet UILabel *titleL3;

@property (nonatomic,weak) IBOutlet UIImageView *meinvImage;



@end




























