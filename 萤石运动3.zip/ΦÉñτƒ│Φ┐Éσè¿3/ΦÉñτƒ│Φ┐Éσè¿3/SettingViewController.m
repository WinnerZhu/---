//
//  SettingViewController.m
//  萤石运动3
//
//  Created by Winner Zhu on 2016/12/18.
//  Copyright © 2016年 Winner Zhu. All rights reserved.
//

#import "SettingViewController.h"
#import "NavHeadTitleView.h"
#import "SettingTableViewCell.h"
#import "GanhuoGroup.h"
#import "AboutMeViewController.h"



#define TheDeviceWidth ([UIScreen mainScreen].bounds.size.width)
#define TheDeviceHeight ([UIScreen mainScreen].bounds.size.height)
#define TheHeightOFcustomNavBar 64



@interface SettingViewController ()

@end

@implementation SettingViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    //0.隐藏系统自带导航栏
    self.navigationController.navigationBar.hidden = YES;
    self.view.backgroundColor = [UIColor whiteColor];
    
    //1.创建UITableView
    [self createTableView];
    
    //2.创建自定义导航栏
    [self createNav];

    //3.创建celltitleArr并添加对象
    [self initData];

    
}


#pragma mark 右滑返回效果
-(void)viewDidAppear:(BOOL)animated{
    if ([[[UIDevice currentDevice]systemVersion]floatValue] >= 7.0) {
        
        self.navigationController.interactivePopGestureRecognizer.enabled = NO;
    }
}


#pragma mark 创建UITableView
-(void)createTableView{
    
    if (_settingTable == nil) {
        
        self.settingTable = [[UITableView alloc]initWithFrame:CGRectMake(0, TheHeightOFcustomNavBar, TheDeviceWidth,TheDeviceHeight -TheHeightOFcustomNavBar) style:UITableViewStyleGrouped];
        _settingTable.bounces = YES;
        _settingTable.delegate = self;
        _settingTable.dataSource = self;
        [_settingTable registerClass:[SettingTableViewCell class]forCellReuseIdentifier:@"thecell"];
        _settingTable.separatorStyle = UITableViewCellSeparatorStyleNone;
        _settingTable.backgroundColor = [UIColor colorWithRed:235.0/255.0 green:235.0/255.0 blue:241.0/255.0 alpha:255.0/255.0];
        
    }
    
    [self.view addSubview:_settingTable];
    
}


#pragma mark 返回cell内容
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    //group and title
    GanhuoGroup *randomGroup = groupArrary[indexPath.section];
    NSString *randomTitle = randomGroup.ganhuos[indexPath.row];
    
    //创建cell
    SettingTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"thecell"];
    if (!cell) {
        cell = [[SettingTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"thecell"];
    }
    
    cell.content = randomTitle;
    
    return cell;
}


#pragma mark - UITableView代理方法
#pragma mark - 重新设置单元格高度
-(CGFloat )tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    /*
    SettingTableViewCell *cell = cellTitleArr[indexPath.row];
    cell.content = cellTitleArr[indexPath.row];
    */
    
    return 40;
    
}

#pragma mark - 返回每组头标题名称
-(NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{
    
    GanhuoGroup *group = groupArrary[section];
    return  group.groupname;
    
}


#pragma mark - UITableView数据源方法
#pragma mark - 返回每组行数
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    GanhuoGroup *group = groupArrary[section];
    return group.ganhuos.count;
    
}


#pragma mark - 返回分组数
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    
    return groupArrary.count;
    
}


#pragma mark - 选择某行
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    //NSIndexPath是一个对象,记录了组和行信息;
    if (indexPath.section == 0 && indexPath.row == 0) {

        NSURL *appStoreUrl = [NSURL URLWithString:@"http://phobos.apple.com/WebObjects/MZStore.woa/wa/viewSoftware?id=291586600&amp;amp;mt=8"];
        [[UIApplication sharedApplication]openURL:appStoreUrl];
        
    }else if (indexPath.section == 0 && indexPath.row == 1){

        [[UIApplication sharedApplication]openURL:[NSURL URLWithString:@"mailto://343990209@qq.com"]];
        
    }else if (indexPath.section == 1 && indexPath.row == 0){

        AboutMeViewController *aboutMeVc = [[AboutMeViewController alloc]init];
        [self.navigationController pushViewController:aboutMeVc animated:YES];
        
    }else if (indexPath.section == 1 && indexPath.row == 1){
        
    }
    
    
}


#pragma mark - 创建导航栏
-(void)createNav{
    
    self.NavView = [[NavHeadTitleView alloc]initWithFrame:CGRectMake(0, 0, TheDeviceWidth,TheHeightOFcustomNavBar)];
    self.NavView.nameTitle = @"设置";
    self.NavView.color = [UIColor blackColor];//这里竟然控制title颜色竟然是title
    self.NavView.backTitleImage = @"home24.png"; //@"Mail";
    self.NavView.rightTitleImage = @""; //Setting
    self.NavView.delegate = self;
    [self.view addSubview:self.NavView];
    
}


#pragma mark - 左侧按钮selector
-(void)NavHeadToLeft{
    
    [self dismissViewControllerAnimated:YES completion:nil];
    
}


#pragma mark - 右侧按钮selector
-(void)NavHeadToRight{
    
}


-(void)initData{
    
    //1.
    dataArr1 = [[NSArray alloc]initWithObjects:@"去AppStore评价！",@"发个反馈邮件给程序猿",nil];
    dataArr2 = [[NSArray alloc]initWithObjects:@"关于",@"最新版本", nil];
    
    feedbackArr = [[NSMutableArray alloc]init];
    aboutAnvVersionArr = [[NSMutableArray alloc]init];
    
    titleCellsArr = [[NSMutableArray alloc]init];
    groupArrary = [[NSMutableArray alloc]init];
    
    //2.
    for (NSString *tempStr in dataArr1) {
        
        NSString *titleStr = [NSString stringWithString:tempStr];
        [feedbackArr addObject:titleStr];
        
        SettingTableViewCell *settingCell = [[SettingTableViewCell alloc]init];
        [titleCellsArr addObject:settingCell];
        
    }//End for
    
    for (NSString *tempStr in dataArr2 ) {
        
        NSString *titleStr = [NSString stringWithString:tempStr];
        [aboutAnvVersionArr addObject:titleStr];
        
        SettingTableViewCell *settingCell = [[SettingTableViewCell alloc]init];
        [titleCellsArr addObject:settingCell];
        
    }//End for
    
    
    
    //3.group
    GanhuoGroup *feedbackGroup = [GanhuoGroup initWithGroupname:@" " andGanhuos:feedbackArr];
    [groupArrary addObject:feedbackGroup];
    
    GanhuoGroup *aboutAndVerGroup = [GanhuoGroup initWithGroupname:@" " andGanhuos: aboutAnvVersionArr];
    [groupArrary addObject:aboutAndVerGroup];
    
    
    
    
    
    
    
    
    
    
    
  

}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
