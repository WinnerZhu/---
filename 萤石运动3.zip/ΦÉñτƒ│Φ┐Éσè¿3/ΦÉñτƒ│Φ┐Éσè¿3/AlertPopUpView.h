//
//  AlertPopUpView.h
//  萤石运动3
//
//  Created by Winner Zhu on 2016/12/10.
//  Copyright © 2016年 Winner Zhu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AlertPopUpView : UIView{
    
    UIView *backgroundView;
    UIView *alertPopUpView;

}


#pragma mark 初始化方法 with frame and string
-(instancetype)initWithFrame:(CGRect)frame alertStr:(NSString *)alertStr;

#pragma mark 弹出方法
-(void)showPopUpViewAnimate:(BOOL)animate;

#pragma mark 隐藏方法
-(void)dismissPopUpViewAnimate:(BOOL)animte;


@end
