//
//  SettingTableViewCell.m
//  萤石运动3
//
//  Created by Winner Zhu on 2016/12/18.
//  Copyright © 2016年 Winner Zhu. All rights reserved.
//

#import "SettingTableViewCell.h"
#import "Masonry.h"


#define AnyColor(r,g,b) [UIColor colorWithHue:r/255.0 saturation:g/255.0 brightness:b/255.0 alpha:1]
#define TableViewCellBackgroundColor AnyColor(251,251,251)
#define TableViewCellLightGrayColor AnyColor(120,120,120)
#define TableViewCellDoveGrayColor [UIColor colorWithRed:113.0/255.0 green:113.0/255.0 blue:113.0/255.0 alpha:255.0/255.0]

#define OneOFGanhuoTabCellDescriptionFontSize 14    //description字体
#define OneOFGanhuoTabCellVerticalControlSpacing 10  //纵向控件间距
#define OneOFGanhuoTabCellHorizontalControlSpacing 15  //横向控件间距

#define TheDeviceWidth ([UIScreen mainScreen].bounds.size.width)
#define TheDeviceHeight ([UIScreen mainScreen].bounds.size.height)



@implementation SettingTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}



- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    
    //[super setSelected:selected animated:animated];

}


#pragma mark 初始化UITableViewCell
-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self initSubView];
    }
    return self;
    
}

-(void)initSubView{
    
    _contentLabel = [[UILabel alloc]init];
    _contentLabel.textColor = TableViewCellDoveGrayColor;
    _contentLabel.font = [UIFont systemFontOfSize:OneOFGanhuoTabCellDescriptionFontSize];
    _contentLabel.numberOfLines = 0;
    
    UIView *lineView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, TheDeviceWidth, 0.5)];
    lineView.backgroundColor = [UIColor colorWithRed:238.0/255.0 green:238.0/255.0 blue:238.0/255.0 alpha:255.0/255.0];//[UIColor lightGrayColor];
    
    [self.contentView addSubview:lineView];
    [self.contentView addSubview:_contentLabel];
    
}

-(void)setContent:(NSString *)content{
    
    
    //常规conentLab
    CGFloat DescLabelX = OneOFGanhuoTabCellHorizontalControlSpacing;
    CGFloat DescLabelY = OneOFGanhuoTabCellVerticalControlSpacing;
    CGFloat DescLabelWitdth = TheDeviceWidth - OneOFGanhuoTabCellHorizontalControlSpacing*2;
    
    CGSize DescLabelSize = [content boundingRectWithSize:CGSizeMake(DescLabelWitdth, MAXFLOAT) options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName: [UIFont systemFontOfSize:OneOFGanhuoTabCellDescriptionFontSize]} context:nil].size;
    
    CGRect DescLabelRect = CGRectMake(DescLabelX, DescLabelY, DescLabelSize.width, DescLabelSize.height);
    _contentLabel.frame = DescLabelRect;
    _contentLabel.text = content;
    
    //左右式contentLab
    if ([content isEqualToString:@"最新版本"]) {
        
        _versionLab = [[UILabel alloc]init];
        _versionLab.textColor = TableViewCellDoveGrayColor;
        _versionLab.font = [UIFont systemFontOfSize:OneOFGanhuoTabCellDescriptionFontSize];
        _versionLab.text = @"V0.0.1";
        _versionLab.textAlignment = NSTextAlignmentRight;
        [_versionLab sizeToFit];
        
        [self addSubview:_versionLab];
        [_versionLab mas_makeConstraints:^(MASConstraintMaker *versonLabMake){
            versonLabMake.right.equalTo(self.mas_right).offset(-OneOFGanhuoTabCellHorizontalControlSpacing);
            versonLabMake.centerY.mas_equalTo(_contentLabel.mas_centerY);
            
        }];
        
    }
    
    //高度
    _Height = CGRectGetMaxY(_contentLabel.frame)+OneOFGanhuoTabCellVerticalControlSpacing;
    

}




@end
