//
//  IntradayGanhuoViewController.m
//  萤石运动3
//
//  Created by Winner Zhu on 16/8/17.
//  Copyright © 2016年 Winner Zhu. All rights reserved.
//

#import "IntradayGanhuoViewController.h"
#import "OneOFGanhuoTableViewCell.h"
#import "Ganhuo.h"
#import "GanhuoGroup.h"

#import "ShowGanhuoViewController.h"
#import "HomePageViewController.h"
#import "ShowMeinvPopUpView.h"
#import "AlertPopUpView.h"

#import "NavHeadTitleView.h"
//引入第三方库 用于显示网络加载进度 ※ copy items if need 之后才检测到头文件MBProgressHUD+ADD.h的存在
#import "MBProgressHUD+ADD.h"
#import "CCPNetworking.h"


#define TheDeviceWidth ([UIScreen mainScreen].bounds.size.width)
#define TheDeviceHeight ([UIScreen mainScreen].bounds.size.height)
#define TheMeiNvImageHeight TheDeviceWidth/0.911
#define TheHeightOFcustomNavBar 64
#define AnyColor(r,g,b,a) [UIColor colorWithRed:(r)/255.0 green:(g)/255.0 blue:(b)/255.0 alpha:(a)]
#define fullScreen CGRectMake(0,0, TheDeviceWidth, TheDeviceHeight)

/*
 *720 * 790   rate = 72/79 = width/heigh = 0.911 ; ImageHeight = width/rate
 *
 */


@implementation IntradayGanhuoViewController


-(void)viewDidLoad{
    
    [super viewDidLoad];
    
    //0.将navigationBarHidden设置为hidden(YES)才能显示ShowGanhuoViewController中添加的navigationBar
    //self.navigationController.navigationBarHidden = YES;

    //1.1 初始化UITableView  1.2 添加头视图 在头视图上添加ImageView;
    [self createTableView];
    
    //2.引用第三方NavHeadTitleView 创建导航栏控件内容
    [self createNav];
    
    //3.1网络请求和数据加载
    //[self sendRequest];
    
    //3.2使用CCPNetworking进行网络请求和数据加载
    [self UsingTheClassOFCPPNetworking];
    
    
    //测试右滑返回效果
    //UIBarButtonItem *backItem;※if中的内容是右滑返回的关键;self.navigationItem.leftBarButtonItem是否设置都不重要;
    
    if ([[[UIDevice currentDevice]systemVersion] floatValue] >= 7.0 ) {
        
        self.navigationController.interactivePopGestureRecognizer.enabled = YES;
        self.navigationController.interactivePopGestureRecognizer.delegate = self;
    }
    //self.navigationItem.leftBarButtonItem = backItem;

}



#pragma mark 创建UITableView
-(void)createTableView{
    
    //Part1.初始化UITableView
    self.TableViewForAllOFGanhuo = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, TheDeviceWidth, TheDeviceHeight) style:UITableViewStyleGrouped];
    _TableViewForAllOFGanhuo.delegate = self;
    _TableViewForAllOFGanhuo.dataSource = self;
    [_TableViewForAllOFGanhuo registerClass:[OneOFGanhuoTableViewCell class] forCellReuseIdentifier:@"cell"];
    //设置cell之间的间隔线
    self.TableViewForAllOFGanhuo.separatorStyle  = UITableViewCellSeparatorStyleNone;

    
    //Part2.添加头视图 在头视图上添加ImageView [NSURL- NSData- UIImage]
    //Part2.1 美女ImageViewUi初始化
    //alloc1
    self.headeR = [[UIView alloc]initWithFrame:CGRectMake(0, 0, TheDeviceWidth,TheMeiNvImageHeight)];
    //alloc2
    _MeiNvImageView = [[UIImageView alloc]initWithFrame:_headeR.bounds];
    
    //Part2.2重要的属性设置
    //这个属性的值决定了 当视图的几何形状变化时如何复用它的内容 这里用UIViewContentModeScaleAspectFill 意思是保持内容高宽比 缩放内容 超出视图的部分内容会被裁减 填充UIView
    _MeiNvImageView.contentMode = UIViewContentModeScaleAspectFill;
    //这个属性决定子视图的显示范围 取值为YES时 裁减超出父视图范围的子视图部分 这里就是裁减了 MeinvImageView 超出 headR范围的部分
    _MeiNvImageView.clipsToBounds = YES;
    //将MeinvImageView添加到headerView
    [self.headeR addSubview:_MeiNvImageView];
    
    self.TableViewForAllOFGanhuo.tableHeaderView = _headeR;
    self.TableViewForAllOFGanhuo.backgroundColor = [UIColor whiteColor];
    
    [self.view addSubview:_TableViewForAllOFGanhuo];
    

}



#pragma mark - UITableView代理方法
#pragma mark 重新设置单元格高度
-(CGFloat )tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    GanhuoGroup *RandomGanhuoGroup = TestGanhuoGroupArrary[indexPath.section];
    Ganhuo *RandomGanhuo = RandomGanhuoGroup.ganhuos[indexPath.row];
    
    OneOFGanhuoTableViewCell *cell = TheGanhuoCells[indexPath.row];
    cell.ganhuo = RandomGanhuo;
    
    return cell.Height ;
    
    
}


#pragma mark - UITableView数据源方法
#pragma mark - 返回分组数
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    
    return TestGanhuoGroupArrary.count;

}


#pragma mark - 返回每组行数
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    GanhuoGroup *group = TestGanhuoGroupArrary[section];
    return group.ganhuos.count;//组群.族群中的干货们.干货们的数量
    
}



#pragma mark - 返回每行单元格的内容
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    
    //NSIndexPath是一个对象,记录了组和行信息
    GanhuoGroup *RandomGanhuoGroup = TestGanhuoGroupArrary[indexPath.section];
    Ganhuo *ganhuo = RandomGanhuoGroup.ganhuos[indexPath.row];
    
    OneOFGanhuoTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    if (!cell) {
        cell = [[OneOFGanhuoTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell"];
    }
    cell.ganhuo = ganhuo;
    
    return cell;

}


#pragma mark - 返回每组头标题名称
-(NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{
    
    GanhuoGroup *group = TestGanhuoGroupArrary[section];
    return  group.groupname;
    
}


#pragma mark - 选择其中一行
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(nonnull NSIndexPath *)indexPath{
    
    //NSIndexPath是一个对象,记录了组和行信息
    GanhuoGroup *RandomGanhuoGroup = TestGanhuoGroupArrary[indexPath.section];
    Ganhuo *RandomGanhuo = RandomGanhuoGroup.ganhuos[indexPath.row];
    
    ShowGanhuoViewController *showganhuoViewController = [[ShowGanhuoViewController alloc]init];
    showganhuoViewController.ganhuo = RandomGanhuo;
    showganhuoViewController.hidesBottomBarWhenPushed = YES;
    
    [self.navigationController pushViewController:showganhuoViewController animated:YES];
    
    
}



#pragma mark - 图片下拉后放大的效果
-(void)scrollViewDidScroll:(UIScrollView *)scrollView{
    
    //Part1
    //int 纵向偏移量
    int contentOffsety = scrollView.contentOffset.y;
    //通过scrollView contentOffset设置navigationBar的状态
    if (contentOffsety  <= 70 ) {
        //正在向上推
        
        self.NavView.headBgview.alpha = contentOffsety / 170;
        self.NavView.backTitleImage = @"backhome16w.png"; //@"Mail";
        self.NavView.rightImageView = @"underwear24w.png";
        self.NavView.color = [UIColor whiteColor];//控制title颜色
        self.NavView.nameTitle = nil;
        //状态栏字体白色
        [UIApplication sharedApplication].statusBarStyle = UIStatusBarStyleDefault;
        
    }else{
        //向上推送越过阈值
        
        self.NavView.headBgview.alpha = 1;
        self.NavView.backTitleImage = @"backhome16b.png";  //@"Mail-click";
        self.NavView.rightImageView = @"underwear24b.png";
        self.NavView.color = [UIColor blackColor];  // AnyColor(87, 173, 104, 1);//控制title颜色
        self.NavView.nameTitle = @"客官,您的干货";
        //隐藏黑线
        [self.navigationController.navigationBar setShadowImage:[UIImage new]];
        
        //状态栏字体黑色
        [UIApplication sharedApplication].statusBarStyle = UIStatusBarStyleDefault;
        
    }

    
    //Part2
    /*
     *这里的偏移量是纵向从contentInset算起 则一开始偏移就是0 向下为负 向上为正 下拉
     */
    //获取到tableView偏移量
    CGFloat Offset_y = scrollView.contentOffset.y;
    
    //下拉 纵向偏移量变小 变成负的
    if (Offset_y < 0) {
        
        //拉伸后图片的高度
        CGFloat totalOffset = TheMeiNvImageHeight - Offset_y;  //offset_y小于0, -- == +,拉伸后图片height变大
        
        //图片放大比例
        CGFloat scale = totalOffset / TheMeiNvImageHeight;
        CGFloat width = TheDeviceWidth;
        
        //拉伸后图片的位置
        _MeiNvImageView.frame = CGRectMake(-(width * scale - width)/2, Offset_y, width * scale, totalOffset);

    }//End if

}



-(void)didReceiveMemoryWarning{
    [super didReceiveMemoryWarning];
    
}


#pragma mark - 创建导航栏
-(void)createNav{
    
    self.NavView = [[NavHeadTitleView alloc]initWithFrame:CGRectMake(0, 0, TheDeviceWidth,TheHeightOFcustomNavBar)];
    self.NavView.nameTitle = nil;
    self.NavView.color = [UIColor whiteColor];
    self.NavView.backTitleImage = @"backhome16w.png"; //@"Mail";
    self.NavView.rightTitleImage = @"underwear24w.png"; //Setting
    self.NavView.delegate = self;
    [self.view addSubview:self.NavView];
    
}


#pragma mark - 左侧按钮selector
-(void)NavHeadToLeft{
    
    [self.navigationController popViewControllerAnimated:YES];
    
}



#pragma mark - 右侧按钮selector
-(void)NavHeadToRight{

    //创建干货
    Ganhuo *CreateGanhuoForBeautifulGirlImageView = [[Ganhuo alloc]init];
    CreateGanhuoForBeautifulGirlImageView = TheMeinvImageArrayAfterEnum[0];
    
    //创建ShowMeinvPopUpView
    ShowMeinvPopUpView *popUpView = [[ShowMeinvPopUpView alloc]initWithFrame:self.view.bounds];
    popUpView.ganhuoForImage = CreateGanhuoForBeautifulGirlImageView;
    
    [popUpView showPopUpViewAnimate:YES];
    
    
}



#pragma mark - 使用CPPNetworking,网络请求、数据加载、网络请求时长
-(void)UsingTheClassOFCPPNetworking{
    
    
    //Part1.imageArr
    //1.需要一个array
    NSMutableArray *imageArr = [NSMutableArray array];
    
    //2.设置1 - 8 的随机数y
    int y = (arc4random() % 8) + 1;
    
    int I = 0;
    
    if (y == 1) {
        
        I = 12 + 1;
        
    } else if (y == 2) {
        
        I = 8 + 1;
        
    }else if (y == 3) {
        
        I = 16 + 1;
        
    }else if (y == 4) {
        
        I = 50 + 1;
        
    }else if (y == 5) {
        
        I = 23 + 1;
        
    }else if (y == 6) {
        
        I = 13 + 1;
        
    }else if (y == 7) {
        
        I = 22 + 1;
        
    }else if (y == 8) {
        
        I = 70 + 1;
    }
    
    //2.for循环生成动画所需图片数组
    for (int i = 1; i < I; i ++ ) {
        
        [imageArr addObject:[UIImage imageNamed:[NSString stringWithFormat:@"loading_%d_%d",y,i]]];
        //随机数y,    for循环 i ；
    }

    
    //Part2.合成网络请求Url
    NSString *urlStrP1 = @"http://gank.io/api/day/";
    NSString * urlStr = [urlStrP1 stringByAppendingString:_dateForUrl];
    
    //有数据http://gank.io/api/day/2015/08/07    //有数据的日期15 08 07 ;15 08 06;
    
    
    //Part3.Networking
    [CCPNetworking  getOrPostWithType:GET WithUrl:urlStr params:nil loadingImageArr:imageArr toShowView:self.view.window success:^(id response){
        
        
        
        //Part1 创建数组实例
        //p1
        TheMeinvImageArrayAfterEnum = [[NSMutableArray alloc]init];
        TheiOSGanhuoArrayAfterEnum = [[NSMutableArray alloc]init];
        TheAndroidGanhuoArrayAfterEnum = [[NSMutableArray alloc]init];
        //p2
        TheAppArrayAfterEnum = [[NSMutableArray alloc]init];
        TheVideoArrayAfterEnum = [[NSMutableArray alloc]init];
        TheExpSourceArrayAfterEnum = [[NSMutableArray alloc]init];
        TheWebArrayAfterEnum = [[NSMutableArray alloc]init];
        
        TheGanhuoCells = [[NSMutableArray alloc]init];
        TestGanhuoGroupArrary = [[NSMutableArray alloc]init];
        //end////////////////////////////////////////////////////////////////////////////////
        
        
        
        //Part2 JSON序列化,JSON实例化
        //TheTotalDictionary = response;
        
        //"Category"+"Results"Fr response
        TheArrayForCategory = (NSArray *)response[@"category"];
        TheDictionaryForResults = (NSDictionary *)response[@"results"];
        
        //"iOS""Android""MeinvImage"Fr"Results"
        TheArrayForiOS = (NSArray *)TheDictionaryForResults[@"iOS"];
        TheArrayForAndroid = (NSArray *)TheDictionaryForResults[@"Android"];
        TheArrayForMeinvImage = (NSArray *)TheDictionaryForResults[@"\u798f\u5229"];
        //"休息视频""拓展资源""前端""App" ; 没有找到key,相应就没有value,应该不需要认为过滤
        TheArrayForApp = (NSArray *)TheDictionaryForResults[@"App"];
        TheArrayForVideo = (NSArray *)TheDictionaryForResults[@"\u4f11\u606f\u89c6\u9891"];
        TheArrayForExpSource = (NSArray *)TheDictionaryForResults[@"\u62d3\u5c55\u8d44\u6e90"];
        TheArrayForWeb = (NSArray *)TheDictionaryForResults[@"\u524d\u7aef"];
        //end////////////////////////////////////////////////////////////////////////////////
        
        
        
        //Part3 枚举数组中的item ;
        //p1.enum normal array(ios, android, meinvimage)
        for (NSDictionary *GanhuoOFMeinvImage in TheArrayForMeinvImage) {
            
            Ganhuo *ganhuo = [[Ganhuo alloc]init];
            [ganhuo setValuesForKeysWithDictionary:GanhuoOFMeinvImage];
            [TheMeinvImageArrayAfterEnum addObject:ganhuo];
            
            //存储tableViewCell
            //不需要存储tableviewCell
            
        }//End for
        
        for (NSDictionary *GanhuoOFiOS in TheArrayForiOS) {
            
            Ganhuo *ganhuo = [[Ganhuo alloc]init];
            [ganhuo setValuesForKeysWithDictionary:GanhuoOFiOS];
            [TheiOSGanhuoArrayAfterEnum addObject:ganhuo];
            
            //存储tableViewCell,用于计算tableViewCell高度
            OneOFGanhuoTableViewCell *OneOFiOScell = [[OneOFGanhuoTableViewCell alloc]init];
            [TheGanhuoCells addObject:OneOFiOScell];
            
        }//End for
        
        for (NSDictionary *GanhuoOFAndroid in TheArrayForAndroid) {
            
            Ganhuo *ganhuo = [[Ganhuo alloc]init];
            [ganhuo setValuesForKeysWithDictionary:GanhuoOFAndroid];
            [TheAndroidGanhuoArrayAfterEnum addObject:ganhuo];
            
            //存储tableViewCell,用于计算tableViewCell高度
            OneOFGanhuoTableViewCell *OneOFAndroidcell = [[OneOFGanhuoTableViewCell alloc]init];
            [TheGanhuoCells addObject:OneOFAndroidcell];
            
        }//End for
        
        
        //Part4 Configurating GanhuoGroup (Normal Group)
        GanhuoGroup *TheiOSGroup = [GanhuoGroup initWithGroupname:@"iOS" andGanhuos:[NSMutableArray arrayWithArray:TheiOSGanhuoArrayAfterEnum]];
        [TestGanhuoGroupArrary addObject:TheiOSGroup];
        
        GanhuoGroup *TheAndroidGroup = [GanhuoGroup initWithGroupname:@"Android" andGanhuos:TheAndroidGanhuoArrayAfterEnum];
        [TestGanhuoGroupArrary addObject:TheAndroidGroup];
        
    
        
        //Part3.2+4.2  条件判断,数组个数>0
        
        if (TheArrayForApp.count > 0 ) {
            
            for (NSDictionary *GanhuoOFApp in TheArrayForApp ) {
                
                Ganhuo *ganhuo = [[Ganhuo alloc]init];
                [ganhuo setValuesForKeysWithDictionary:GanhuoOFApp];
                [TheAppArrayAfterEnum addObject:ganhuo];
                
                //存储tableViewCell,用于计算tableViewCell高度
                OneOFGanhuoTableViewCell *OneOFAppCell = [[OneOFGanhuoTableViewCell alloc]init];
                [TheGanhuoCells addObject:OneOFAppCell];
                
            }//End for
            
            GanhuoGroup *TheAppGroup = [GanhuoGroup initWithGroupname:@"App" andGanhuos:TheAppArrayAfterEnum];
            [TestGanhuoGroupArrary addObject:TheAppGroup];
            
        }//End if

        //if we have video
        if (TheArrayForVideo.count > 0) {
            
            for (NSDictionary *GanhuoOFVideo in TheArrayForVideo ) {
                
                Ganhuo *ganhuo = [[Ganhuo alloc]init];
                [ganhuo setValuesForKeysWithDictionary:GanhuoOFVideo];
                [TheVideoArrayAfterEnum addObject:ganhuo];
                
                //存储tableViewCell,用于计算tableViewCell高度
                OneOFGanhuoTableViewCell *OneOFVideoCell = [[OneOFGanhuoTableViewCell alloc]init];
                [TheGanhuoCells addObject:OneOFVideoCell];
                
            }//End for
            
            GanhuoGroup *TheVideoGroup = [GanhuoGroup initWithGroupname:@"休闲视频" andGanhuos:TheVideoArrayAfterEnum];
            [TestGanhuoGroupArrary addObject:TheVideoGroup];
            
        }//End if
        
        //if we have expsource
        if (TheArrayForExpSource.count > 0) {
            
            for (NSDictionary *GanhuoOFExpSource in TheArrayForExpSource) {
                
                Ganhuo *ganhuoo =[[Ganhuo alloc]init];
                [ganhuoo setValuesForKeysWithDictionary:GanhuoOFExpSource];
                [TheExpSourceArrayAfterEnum addObject:ganhuoo];
                
                //存储tableViewCell,用于计算tableViewCell高度
                OneOFGanhuoTableViewCell *OneOFExpSourceCell = [[OneOFGanhuoTableViewCell alloc]init];
                [TheGanhuoCells addObject:OneOFExpSourceCell];
                
            }//End for
            
            GanhuoGroup *TheExpSourceGroup = [GanhuoGroup initWithGroupname:@"拓展资源" andGanhuos:TheExpSourceArrayAfterEnum];
            [TestGanhuoGroupArrary addObject:TheExpSourceGroup];
            
        }//End if
        
        //if we have web
        if (TheArrayForWeb.count > 0) {
            
            for (NSDictionary *GanhuoOFWeb in TheArrayForWeb) {
                
                Ganhuo *ganuo = [[Ganhuo alloc]init];
                [ganuo setValuesForKeysWithDictionary:GanhuoOFWeb];
                [TheWebArrayAfterEnum addObject:ganuo];
                
                //存储tableViewCell,用于计算tableViewCell高度
                OneOFGanhuoTableViewCell *OneOFWebCell = [[OneOFGanhuoTableViewCell alloc]init];
                [TheGanhuoCells addObject:OneOFWebCell];
                
            }//End for
         
            GanhuoGroup *TheWebGroup = [GanhuoGroup initWithGroupname:@"前端" andGanhuos:TheWebArrayAfterEnum];
            [TestGanhuoGroupArrary addObject:TheWebGroup];
            
        }//End if
        //end////////////////////////////////////////////////////////////////////////////////
        
        
        
        //Part5 调用上述从服务器获取的数据并赋值
        //Part2.1 美女ImageView数据加载部分 → 移动这部分内容
        Ganhuo *GetMeinvImageFrThis =[[Ganhuo alloc]init];
        GetMeinvImageFrThis = TheMeinvImageArrayAfterEnum[0];
        
        NSURL *MeinvImageUrl = [NSURL URLWithString:GetMeinvImageFrThis.url];
        NSData *MeinvImageData = [NSData dataWithContentsOfURL:MeinvImageUrl];
        UIImage *MeinvImage = [UIImage imageWithData:MeinvImageData];
        
        _MeiNvImageView.image = MeinvImage;
        //end////////////////////////////////////////////////////////////////////////////////
        
        
        //Part6 加载数据完成后刷新TableView
        [self.TableViewForAllOFGanhuo reloadData];
        
    
        
    }fail:^(NSError *error){
        //此处为一个block代码块
        AlertPopUpView *alertView = [[AlertPopUpView alloc]initWithFrame:fullScreen alertStr:@"请求超时啦"];
        [alertView showPopUpViewAnimate:YES];
        
    }showHUD:YES];
    
    
}


#pragma mark get



#pragma mark - 网络请求和数据加载
#pragma mark - 加载数据方法
-(void)loadData:(NSData *)data{  //有可能是因为这个方法没有返回NSArray数据
    
    
    //Part1 创建数组实例
    TheMeinvImageArrayAfterEnum = [[NSMutableArray alloc]init];
    TheiOSGanhuoArrayAfterEnum = [[NSMutableArray alloc]init];
    TheAndroidGanhuoArrayAfterEnum = [[NSMutableArray alloc]init];
    TheGanhuoCells = [[NSMutableArray alloc]init];
    TestGanhuoGroupArrary = [[NSMutableArray alloc]init];
    //end////////////////////////////////////////////////////////////////////////////////
    
    
    //Part2 JSON序列化,JSON实例化
    /*json序列化
     *option = 0,返回NSDictionary或者NSarray
     */
    NSError *error;
    //将对象序列化为字典
    TheTotalDictionary = [NSJSONSerialization JSONObjectWithData:data options:0 error:&error];
    
    //"Category"+"Results"Fr Total
    TheArrayForCategory = (NSArray *)TheTotalDictionary[@"category"];
    TheDictionaryForResults = (NSDictionary *)TheTotalDictionary[@"results"];
    
    //"iOS""Android""MeinvImage"Fr"Results"
    TheArrayForiOS = (NSArray *)TheDictionaryForResults[@"iOS"];
    TheArrayForAndroid = (NSArray *)TheDictionaryForResults[@"Android"];
    TheArrayForMeinvImage = (NSArray *)TheDictionaryForResults[@"\u798f\u5229"];
    //end////////////////////////////////////////////////////////////////////////////////
    
    
    //Part3 枚举数组中的item
    //for (...in...)  ≈  //EnumerateObjectsUsingBlock//
    for (NSDictionary *GanhuoOFMeinvImage in TheArrayForMeinvImage) {
        
        Ganhuo *ganhuo = [[Ganhuo alloc]init];
        [ganhuo setValuesForKeysWithDictionary:GanhuoOFMeinvImage];
        [TheMeinvImageArrayAfterEnum addObject:ganhuo];
        
        //存储tableViewCell
        //不需要存储tableviewCell
        
    }//End for
    
    
    for (NSDictionary *GanhuoOFiOS in TheArrayForiOS) {
        
        Ganhuo *ganhuo = [[Ganhuo alloc]init];
        [ganhuo setValuesForKeysWithDictionary:GanhuoOFiOS];
        [TheiOSGanhuoArrayAfterEnum addObject:ganhuo];
        
        //存储tableViewCell
        OneOFGanhuoTableViewCell *OneOFiOScell = [[OneOFGanhuoTableViewCell alloc]init];
        [TheGanhuoCells addObject:OneOFiOScell];
        
    }//End for
    
    
    for (NSDictionary *GanhuoOFAndroid in TheArrayForAndroid) {
        
        Ganhuo *ganhuo = [[Ganhuo alloc]init];
        [ganhuo setValuesForKeysWithDictionary:GanhuoOFAndroid];
        
        [TheAndroidGanhuoArrayAfterEnum addObject:ganhuo];
        
        //存储tableViewCell
        OneOFGanhuoTableViewCell *OneOFAndroidcell = [[OneOFGanhuoTableViewCell alloc]init];
        [TheGanhuoCells addObject:OneOFAndroidcell];
        
    }//End for
    
    //end////////////////////////////////////////////////////////////////////////////////
    
    
    //Part4 Configurating GanhuoGroup
    
    GanhuoGroup *TheiOSGroup = [GanhuoGroup initWithGroupname:@"iOS" andGanhuos:[NSMutableArray arrayWithArray:TheiOSGanhuoArrayAfterEnum]];
    [TestGanhuoGroupArrary addObject:TheiOSGroup];
    
    GanhuoGroup *TheAndroidGroup = [GanhuoGroup initWithGroupname:@"Android" andGanhuos:TheAndroidGanhuoArrayAfterEnum];
    [TestGanhuoGroupArrary addObject:TheAndroidGroup];
    //end////////////////////////////////////////////////////////////////////////////////
    
    
    //Part5 调用上述从服务器获取的数据并赋值
    //Part2.1 美女ImageView数据加载部分 → 移动这部分内容
    Ganhuo *GetMeinvImageFrThisGanhuo = [[Ganhuo alloc]init];
    GetMeinvImageFrThisGanhuo = TheMeinvImageArrayAfterEnum[0];
    
    NSURL *MeinvImageUrl = [NSURL URLWithString: GetMeinvImageFrThisGanhuo.url ];
    NSData *MeinvImageData = [NSData dataWithContentsOfURL:MeinvImageUrl];
    UIImage *MeinvImage = [UIImage imageWithData:MeinvImageData];
    
    _MeiNvImageView.image = MeinvImage;
    //end////////////////////////////////////////////////////////////////////////////////
    
    
}



#pragma mark 发送网络请求
-(void)sendRequest{
    
    NSString *urlStrP1 = @"http://gank.io/api/day/";
    NSString * urlStr = [urlStrP1 stringByAppendingString:_dateForUrl];
    
    NSLog(@"[Test urlStr]@sendRequest&Intraday:%@",urlStr);
    //有数据http://gank.io/api/day/2015/08/07    //有数据的日期15 08 07 ;15 08 06;
    
    
    //注意对于url中的中文是无法解析的，需要进行url编码(指定编码类型为UTF-8)
    //另外注意url解码使stringByRemovingPercentEncoding方法
    
    
    urlStr = [urlStr stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    //创建url链接
    NSURL *url = [NSURL URLWithString:urlStr];
    
    //创建可变请求【创建请求】
    NSMutableURLRequest *requestMut = [[NSMutableURLRequest alloc]initWithURL:url cachePolicy:0 timeoutInterval:5.0f];
    [requestMut setHTTPMethod:@"GET"];//设置为post请求,,傻逼 应该是GET请求
    
    //发送一个异步请求【创建连接】
    [NSURLConnection sendAsynchronousRequest:requestMut queue:[NSOperationQueue mainQueue] completionHandler:^(NSURLResponse *response , NSData *data , NSError *connectionError ){
        
        if (!connectionError ) {
            
            //先执行【数据加载】方法,再执行【刷新视图】方法
            //加载数据
            [self loadData:data];//self,自己执行loadData方法,参数是data
            //刷新视图
            [_TableViewForAllOFGanhuo reloadData];
            
        }else{
            
            [[NSOperationQueue mainQueue]addOperationWithBlock:^{
                
                
            }];
        }
        
    }];
    
}










@end
