//
//  FavouriteGanhuo.h
//  萤石运动3
//
//  Created by Winner Zhu on 2016/11/6.
//  Copyright © 2016年 Winner Zhu. All rights reserved.
//

#import "BQLDBModel.h"

#define FavouriteGanhuoFile @"favouriteganhuo.sqlite"

@interface FavouriteGanhuo : BQLDBModel

/*
@property (nonatomic,copy) NSString *idstring;
@property (nonatomic,copy) NSString *createdat;
@property (nonatomic,copy) NSString *publishedat;
@property (nonatomic,copy) NSString *type;
@property (nonatomic,copy) NSString *used;
@property (nonatomic,copy) NSString *who;
@property (nonatomic,copy) NSString *source;
@property (nonatomic,copy) NSString *images;
*/
 
@property (nonatomic,copy) NSString *favganhuourl;
@property (nonatomic,copy) NSString *favganhuodesc;

@end
