//
//  NavHeadTitleView.h
//  萤石运动3
//
//  Created by Winner Zhu on 16/9/24.
//  Copyright © 2016年 Winner Zhu. All rights reserved.
//

#import <UIKit/UIKit.h>


@protocol NavHeadTitleViewDelegate <NSObject>

@optional
-(void)NavHeadToLeft;
-(void)NavHeadToRight;

@end

@interface NavHeadTitleView : UIView

//看到没？delegate(代理)也是由property定义的
@property (nonatomic,assign) id<NavHeadTitleViewDelegate>delegate;
@property (nonatomic,strong) UIImageView *headBgview;
@property (nonatomic,strong) NSString *nameTitle;
@property (nonatomic,strong) UIColor  *color;
@property (nonatomic,strong) NSString *backTitleImage;
@property (nonatomic,strong) NSString *rightImageView;
@property (nonatomic,strong) NSString *rightTitleImage;





@end
