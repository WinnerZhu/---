//
//  CellModel.m
//  LearningParserHTML
//
//  Created by Winner Zhu on 2016/11/30.
//  Copyright © 2016年 Winner Zhu. All rights reserved.
//

#import "CellModel.h"

@implementation CellModel

@end
