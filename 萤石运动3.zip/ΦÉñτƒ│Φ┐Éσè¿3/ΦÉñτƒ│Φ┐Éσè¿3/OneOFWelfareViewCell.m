//
//  OneOFWelfareViewCell.m
//  萤石运动3
//
//  Created by Winner Zhu on 2016/11/25.
//  Copyright © 2016年 Winner Zhu. All rights reserved.
//

#import "OneOFWelfareViewCell.h"
#import "Ganhuo.h"

#define OneOFGanhuoTableViewCellControlSpacing 4  //控件间距
#define TheDeviceWidth ([UIScreen mainScreen].bounds.size.width)
#define TheDeviceHeight ([UIScreen mainScreen].bounds.size.height)
#define SizeOfCollectionCell CGRectGetWidth(self.frame)


@implementation OneOFWelfareViewCell


-(instancetype)initWithFrame:(CGRect)frame{
    
    self = [super initWithFrame:frame];
    if (self) {
        
        [self initSubView];
    }
    
    return self;
}



-(void)initSubView{
    
    
    self.welfareImageView = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, SizeOfCollectionCell , SizeOfCollectionCell )];
    
    self.welfareImageView.contentMode = UIViewContentModeScaleAspectFill;
    self.welfareImageView.clipsToBounds = YES;
    //UIViewContentModeScaleAspectFit   图片比例不变,UIImageViewbubian,图片与ImageView之间有空白;
    //UIViewContentModeScaleAspectFill  图片比例不变,UIImageView大小由图片比例决定;
    //UIViewContentModeScaleToFill  图片比例变化,UIImageView大小有自身决定;
    
    [self addSubview:self.welfareImageView];
    
    
}



@end
