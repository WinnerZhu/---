//
//  AboutMeViewController.h
//  萤石运动3
//
//  Created by Winner Zhu on 2016/12/19.
//  Copyright © 2016年 Winner Zhu. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "NavHeadTitleView.h"



@interface AboutMeViewController : UIViewController <NavHeadTitleViewDelegate>{
    
    UIImageView *iconImageView;
    UILabel *versionLab;
    UIView *lineView;
    UILabel *descLab;
    UIView *lineView1;
    UILabel *aboutMeLab;
    UIView *lineView2;
    UILabel *linkLab;
    UIButton *linkBtn;
    
}


@property (nonatomic,strong)NavHeadTitleView *NavView;//导航栏

@end
