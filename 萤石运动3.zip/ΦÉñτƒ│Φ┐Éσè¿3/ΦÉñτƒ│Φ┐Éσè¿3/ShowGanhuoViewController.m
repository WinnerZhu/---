//
//  ShowGanhuoViewController.m
//  萤石运动3
//
//  Created by Winner Zhu on 16/8/31.
//  Copyright © 2016年 Winner Zhu. All rights reserved.
//

#import "ShowGanhuoViewController.h"
#import "IntradayGanhuoViewController.h"

#import "NJKWebViewProgressView.h"
#import "NJKWebViewProgress.h"

#define TheDeviceWidth ([UIScreen mainScreen].bounds.size.width)
#define TheDeviceHeight ([UIScreen mainScreen].bounds.size.height)

#import "BQLDBTool.h"
#import "BQLElseTool.h"
#import "FavouriteGanhuo.h"

@implementation ShowGanhuoViewController


#pragma mark - 界面UI事件

-(void)viewDidLoad{
    
    [super viewDidLoad];
    
    //以下两行存在与否都不影响自定义的navigationBar显示
    [self.navigationController setNavigationBarHidden:YES animated:NO];
    
    [self layoutUI];
    
    [self addWebViewProgress];
    
    [self startFMDBoperation];

    [self request:self.UrlFORRequest]; //※_UrlFORRequest是不行的
    
    //临时清除数据库中多所有内容
    //[Tool deleteDataWith:FavouriteGanhuoFile];
    
    
    //测试右滑返回效果
    //UIBarButtonItem *backItem;
    //※ if中的内容是右滑返回的关键;self.navigationItem.leftBarButtonItem是否设置都不重要;
    if ([[[UIDevice currentDevice]systemVersion] floatValue] >= 7.0 ) {
        
        self.navigationController.interactivePopGestureRecognizer.enabled = YES;
        self.navigationController.interactivePopGestureRecognizer.delegate = self;
    }
    //self.navigationItem.leftBarButtonItem = backItem;
    
    
}


#pragma mark - 私有方法
#pragma mark 界面布局
-(void)layoutUI{
    
    
    //1.添加浏览器控件
    webView = [[UIWebView alloc]initWithFrame:CGRectMake(0, 44, TheDeviceWidth, TheDeviceHeight)];
    webView.dataDetectorTypes = UIDataDetectorTypeAll;//数据检测,例如内容中有邮件地址,点击之后可以打开邮件软件编写邮件
    webView.delegate = self;
    [self.view addSubview:webView];
    
    
    //2.添加导航栏
    navigationBar = [[UINavigationBar alloc]initWithFrame:CGRectMake(0, 0, TheDeviceWidth, 44 + 20)];
    [self.view addSubview:navigationBar];
    
    //创建导航栏控件内容
    
    navigationItem  = [[UINavigationItem alloc]initWithTitle:self.TitleOFViewController];
    
    barButtonNaviBack = [[UIBarButtonItem alloc]initWithImage:[UIImage imageNamed:@"naviback32px.png"] style:UIBarButtonItemStyleDone target:self action:@selector(Previous)];
    barButtonNaviReload = [[UIBarButtonItem alloc]initWithImage:[UIImage imageNamed:@"navireload32px.png"] style:UIBarButtonItemStyleDone target:self action:@selector(Reload)];
    
    navigationItem.leftBarButtonItem = barButtonNaviBack;
    navigationItem.rightBarButtonItem = barButtonNaviReload;
    
    
    //添加内容到导航栏
    [navigationBar pushNavigationItem:navigationItem animated:YES];
   
    //3.添加工具栏
    toolBar = [[UIToolbar alloc]initWithFrame:CGRectMake(0, TheDeviceHeight - 44, TheDeviceWidth, 44)];
    
    UIButton *btnBack = [UIButton buttonWithType:UIButtonTypeCustom];
    btnBack.bounds = CGRectMake(0, 0, 32, 32) ;
    [btnBack setImage:[UIImage imageNamed:@"toolback32px.png"] forState:UIControlStateNormal];
    [btnBack setImage:[UIImage imageNamed:@"toolno32px.png"] forState:UIControlStateDisabled];
    [btnBack addTarget:self  action:@selector(webViewBack) forControlEvents:UIControlEventTouchUpInside];
    barButtonToolGoBack = [[UIBarButtonItem alloc]initWithCustomView:btnBack];
    barButtonToolGoBack.enabled = NO;  //将该按钮的默认状态设置为bukedong
    
    /*
    UIButton *btnShare = [UIButton buttonWithType:UIButtonTypeCustom];
    btnShare.bounds = CGRectMake(0, 0, 32, 32);
    [btnShare setImage:[UIImage imageNamed:@"toolshare32px.png"] forState:UIControlStateNormal];
    [btnShare addTarget:self action:@selector(shareGanhuo) forControlEvents:UIControlEventTouchUpInside];
    barButtonToolShare = [[UIBarButtonItem alloc]initWithCustomView:btnShare];
    barButtonToolShare.enabled = YES;  //将该按钮的默认状态设置为kedong
    */
     
    UIButton *btnForward = [UIButton buttonWithType:UIButtonTypeCustom];
    btnForward.bounds = CGRectMake(0, 0, 32, 32);
    [btnForward setImage:[UIImage imageNamed:@"toolforward32px.png"] forState:UIControlStateNormal];
    [btnForward setImage:[UIImage imageNamed:@"toolno32px.png"] forState:UIControlStateDisabled];
    [btnForward addTarget:self action:@selector(webViewForward) forControlEvents:UIControlEventTouchUpInside];
    barButtonToolGoForward = [[UIBarButtonItem alloc]initWithCustomView:btnForward];
    barButtonToolGoForward.enabled = NO;  //将该按钮的默认状态设置为bukedong
    
    UIButton *btnFavorite = [UIButton buttonWithType:UIButtonTypeCustom];
    btnFavorite.bounds = CGRectMake(0, 0, 32, 32);
    [btnFavorite setImage:[UIImage imageNamed:@"favgray32.png"] forState:UIControlStateNormal];
    [btnFavorite addTarget:self action:@selector(changeButtonUIControlState:) forControlEvents:UIControlEventTouchUpInside];
    barButtonToolFavorite = [[UIBarButtonItem alloc]initWithCustomView:btnFavorite];
    
    UIBarButtonItem *btnSpacing = [[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil];
    
    toolBar.items=@[barButtonToolGoBack,btnSpacing,barButtonToolFavorite,btnSpacing,barButtonToolGoForward];
    [self.view addSubview:toolBar];
    

    
}


#pragma mark WebViewProgress浏览器进度条
-(void)addWebViewProgress{
    
    webViewProgressProxy = [[NJKWebViewProgress alloc]init];
    webView.delegate = webViewProgressProxy;
    webViewProgressProxy.webViewProxyDelegate = self;
    webViewProgressProxy.progressDelegate = self;
    
    CGFloat progressBarHeight = 2.f;
    CGRect barFrame = CGRectMake(0, 44 +20 , TheDeviceWidth ,  progressBarHeight);
    
    webViewProgressView = [[NJKWebViewProgressView alloc]initWithFrame:barFrame];
    webViewProgressView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleTopMargin ;
    
   // [self request:_ganhuo.url];
    
}



#pragma mark - Click Btn On The NavigationBar
-(void)Previous{
 
    [self.navigationController popViewControllerAnimated:YES];
    
    //IntradayGanhuoViewController *intradayGanhuoVc = [[IntradayGanhuoViewController alloc]init];
    //[self.navigationController popToViewController:intradayGanhuoVc animated:YES];
    

}

#pragma mark - Click Btn On The NavigationBar
-(void)Reload{
    
    [webView reload];
    [webView scrollViewDidScrollToTop:webView.scrollView];
    
}


#pragma mark 设置前进后退[按钮状态]
-(void)setBarButtonStatus{
    
    //Status1
    if (webView.canGoBack) {
        barButtonToolGoBack.enabled = YES;
        
    }else{
        barButtonToolGoBack.enabled = NO;
    }
    
    //Status2
    if (webView.canGoForward) {
        barButtonToolGoForward.enabled = YES;
    }else{
        barButtonToolGoForward.enabled = NO;
    }
    
    
}


#pragma mark - Click Btn On Tool
#pragma mark 后退
-(void)webViewBack{
    
    [webView goBack];
    
}


#pragma mark 前进
-(void)webViewForward{
    
    [webView goForward];
    
}


#pragma mark 分享
-(void)shareGanhuo{
    
}

#pragma mark 改变Button状态
-(void)changeButtonUIControlState:(UIButton *)sender{
    
    /*
     *1.初始状态(未收藏)为灰色  2.收藏后显示黑色(红色),取消收藏(未收藏)后显示灰色
     */
    sender.selected = ! sender.selected;
    if (sender.selected) { //收藏
        
        [sender setImage:[UIImage imageNamed:@"favred32.png"] forState:UIControlStateSelected];
        [self favoriteGanhuo];
    } else {  //取消收藏(未收藏)
        
        [sender setImage:[UIImage imageNamed:@"favgray32.png"] forState:UIControlStateNormal];
        [self favoriteCancel];
    }
    
}


#pragma mark -FMBD操作-创建或打开数据库
-(void)startFMDBoperation{
    
    //借助viewDidLoad方法打开或创建数据库
    //Step1.初始化BQLTool
    Tool = [BQLDBTool instantiateTool];
    
    //Step2.打开或创建数据库(数据库要根据模型决定创建哪些字段)
    NSDictionary *FavouriteGanhuoDicForCreateDB = @{
                                                    //@"idstring":@"",
                                                    //@"createdat":@"",
                                                    //@"publishedat":@"",
                                                    //@"typ":@"",
                                                    //@"used":@"",
                                                    //@"who":@"",
                                                    //@"source":@"",
                                                    //@"images":@""
                                                    
                                                    @"favganhuodesc":@"",
                                                    @"favganhuourl":@"",
                                                    };
    
    FavouriteGanhuo *model = [FavouriteGanhuo modelWithDictionary:FavouriteGanhuoDicForCreateDB];
    [Tool openDBWith:FavouriteGanhuoFile Model:model];
    
}

#pragma mark -FMBD操作-收藏干货
-(void)favoriteGanhuo{
    
    //if tool是否存在
    if (!Tool) {
        Tool = [BQLDBTool instantiateTool];
    }
    
    //Step1.创建目标字典(即存入对象,存入目标)
    NSDictionary *GetDescANDUrl = @{
                                     //@"idstring": _ganhuo._id,
                                     //@"createdat":_ganhuo.createdAt,
                                     //@"publishedat":_ganhuo.publishedAt,
                                     //@"typ":_ganhuo.type,
                                     //@"used":_ganhuo.used,
                                     //@"who":_ganhuo.who,
                                     //@"source":_ganhuo.source,
                                     //@"images":_ganhuo.images
                                    
                                     @"favganhuourl":_ganhuo.url,
                                     @"favganhuodesc":_ganhuo.desc,
                                     };
    
    NSLog(@"[Test]desc:%@,url:%@",_ganhuo.desc,_ganhuo.url);
    
    
    //此处FavouriteGanhuo *model的model是私有的;我们需要一个公有model用于删除数据;→测试使用.h中的property model
    _FavouriteGanhuoModel = [FavouriteGanhuo modelWithDictionary:GetDescANDUrl];

    
    //Step2.insertData 并给出警告标示
    if ( [Tool insertDataWith:FavouriteGanhuoFile Model:_FavouriteGanhuoModel] ) {
        [self showAlert:@"已收藏Y(^o^)Y"];
    } else {
        [self showAlert:@"/(ㄒoㄒ)/ 收藏未成功"];
    }
    
    
}


#pragma mark -FMBD操作-取消收藏(未收藏) ※并没有达到效果,点击[取消收藏]后刚才收藏的ganhuo的还在。
-(void)favoriteCancel{
    
    if ([Tool deleteDataWith:FavouriteGanhuoFile Identifier:@"customid" IdentifierValue:[NSString stringWithFormat:@"%lld",_FavouriteGanhuoModel.customID]]) {
        [self showAlert:@"取消收藏 (ˉ▽￣～) 切~~"];
    } else {
        [self showAlert:@"木有取消成功￣へ￣"];
    }

    
}


#pragma mark 给出警告标示
-(void)showAlert:(NSString *)message{
    
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"温馨提示(⊙v⊙)" message:message preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *OkAction = [UIAlertAction actionWithTitle:@"好的嘛 \(^o^)/" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action){
        
    }];
    
    [alertController addAction:OkAction];
    [self presentViewController:alertController animated:YES completion:nil];
    
}



#pragma mark setganhuo 提供URL
-(void)setGanhuo:(Ganhuo *)ganhuo{
    
    _ganhuo = ganhuo;
       
}

#pragma mark setfavourite 收藏的干货用于网络访问 
-(void)setFavGanhuoForNetw:(FavouriteGanhuo *)FavGanhuoForNetw{
    
    _FavGanhuoForNetw = FavGanhuoForNetw;
    
}

#pragma mark set Title of ViewController
-(NSString *)TitleOFViewController{
    
    if (_ganhuo.url > 0) {
        _TitleOFViewController = _ganhuo.desc;
    }else{
        _TitleOFViewController = _FavGanhuoForNetw.favganhuodesc;
    }
    
    return _TitleOFViewController;
}

#pragma mark set Url for request
-(NSString *)UrlFORRequest{
    
    if (_ganhuo.url > 0) {
        _UrlFORRequest = _ganhuo.url;
    }else{
        _UrlFORRequest = _FavGanhuoForNetw.favganhuourl;
    }
    
    return _UrlFORRequest;
}



#pragma mark 浏览器请求
-(void)request:(NSString *)GanhuoUrlStr{  //-(void)request:(NSString *)urlStr
    
    //创建Url
    NSURL *TheUrlOFStr;
    
    if (GanhuoUrlStr > 0 ) {
        
        TheUrlOFStr = [NSURL URLWithString:GanhuoUrlStr];
        //需要注意此处得到的Url是否需要编码
        
    }else{
        
    }
    
    //创建请求
    NSURLRequest *request = [NSURLRequest requestWithURL:TheUrlOFStr];
    
    //加载请求页面
    [webView loadRequest:request];
   
}


#pragma mark - webView 代理方法
#pragma mark 开始加载
-(void)webViewDidStartLoad:(UIWebView *)webView{
    
    //显示[网络请求加载图标]
    [UIApplication sharedApplication].networkActivityIndicatorVisible = true;
    
}


#pragma mark 加载完毕
-(void)webViewDidFinishLoad:(UIWebView *)webView{
    
    //隐藏[网络请求加载图标]
    [UIApplication sharedApplication].networkActivityIndicatorVisible = false;
    //设置按钮状态
    [self setBarButtonStatus];
    
}



/*
#pragma mark 加载失败
-(void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error{
    
    //NSLog(@"Error detail:%@",error.localizedDescription);
    UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"友情提示" message:@"网络连接发生错误" delegate:self cancelButtonTitle:nil otherButtonTitles:@"好吧", nil];
    
    [alert show];
    
}
*/



#pragma mark 以下为addWebViewProgress的附带内容
-(void)viewWillAppear:(BOOL)animated{
    
    [super viewWillAppear:animated];
    [navigationBar addSubview:webViewProgressView];
    
}

-(void)viewWillDisappear:(BOOL)animated{
    
    [super viewWillDisappear:animated];
    [webViewProgressView removeFromSuperview];
    
}


#pragma mark NJKWebViewProgressDelegate
-(void)webViewProgress:(NJKWebViewProgress *)webViewProgress updateProgress:(float)progress{
    
    [webViewProgressView setProgress:progress animated:YES];
    self.title = [webView stringByEvaluatingJavaScriptFromString:@"document.title"];
                
    
}





@end
