//
//  UploadPopUpView.h
//  TestPopupView
//
//  Created by Winner Zhu on 2016/12/7.
//  Copyright © 2016年 Winner Zhu. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface UploadPopUpView : UIView

#pragma mark 定义显示分类的UILabel用于显示UIPickerView结果
@property (nonatomic,strong) UILabel * pickerResLabel;

#pragma mark 定义BOOL值监控 pickerView是否appear
@property (nonatomic,assign) BOOL pickerViewWhetherAppear;

#pragma mark 初始化方法
-(instancetype)initWithFrame:(CGRect)frame;

#pragma mark 弹出PopUpView
-(void)showPopUpViewAnimate:(BOOL)animate;

#pragma mark 隐藏PopUpView
-(void)dismissPopUpViewAnimate:(BOOL)animte;


@end
