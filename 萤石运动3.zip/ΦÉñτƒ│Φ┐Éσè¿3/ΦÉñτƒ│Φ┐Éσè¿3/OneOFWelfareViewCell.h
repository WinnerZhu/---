//
//  OneOFWelfareViewCell.h
//  萤石运动3
//
//  Created by Winner Zhu on 2016/11/25.
//  Copyright © 2016年 Winner Zhu. All rights reserved.
//

#import <UIKit/UIKit.h>
@class Ganhuo;



@interface OneOFWelfareViewCell : UICollectionViewCell


#pragma mark - showGirlUIImageView
@property (nonatomic,strong) UIImageView *welfareImageView;

#pragma mark - Ganhuo
@property (nonatomic,strong) Ganhuo *ganhuo;



@end
