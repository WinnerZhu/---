//
//  JSONModel.m
//  LearningParserHTML
//
//  Created by Winner Zhu on 2016/11/27.
//  Copyright © 2016年 Winner Zhu. All rights reserved.
//

#import "JSONModel.h"

@implementation JSONModel

@end
