//
//  IntradayGanhuoViewController.h
//  萤石运动3
//
//  Created by Winner Zhu on 16/8/17.
//  Copyright © 2016年 Winner Zhu. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "NavHeadTitleView.h"


@interface IntradayGanhuoViewController : UIViewController<UITableViewDelegate,UITableViewDataSource,NavHeadTitleViewDelegate>{
    
    NSDictionary *TheTotalDictionary;                 //案例中私有对象
    NSArray *TheArrayForCategory;                     //案例中私有对象//字典category
    NSDictionary *TheDictionaryForResults;            //案例中私有对象//字典result
    
    //p1
    NSArray *TheArrayForAndroid;      //案例中私有对象//字典Android
    NSArray *TheArrayForiOS;          //案例中私有对象//字典iOS
    NSArray *TheArrayForMeinvImage;   //案例中私有对象//字典\u798f\u5229
    //p2
    NSArray *TheArrayForApp;
    NSArray *TheArrayForVideo;
    NSArray *TheArrayForExpSource;
    NSArray *TheArrayForWeb;
    

    //p1
    NSMutableArray *TheMeinvImageArrayAfterEnum;          //枚举美女图片
    NSMutableArray *TheAndroidGanhuoArrayAfterEnum;       //枚举andr
    NSMutableArray *TheiOSGanhuoArrayAfterEnum;           //枚举iOS
    //p2
    NSMutableArray *TheAppArrayAfterEnum;
    NSMutableArray *TheVideoArrayAfterEnum;
    NSMutableArray *TheExpSourceArrayAfterEnum;
    NSMutableArray *TheWebArrayAfterEnum;
    
    
    
    NSMutableArray *TheGanhuoCells;         //存储cell,用预计算高度
    NSMutableArray *TestGanhuoGroupArrary;
    
    
    
}

#pragma mark 日期
@property (nonatomic,strong) NSString *dateForUrl;

#pragma mark 美女图
@property (nonatomic,strong) UIImageView *MeiNvImageView;

#pragma mark TableView
@property (nonatomic,strong) UITableView *TableViewForAllOFGanhuo;

#pragma mark 头UIView
@property (nonatomic,strong) UIView *headeR;

#pragma mark 导航栏 UINavigationBar
@property (nonatomic,strong)NavHeadTitleView *NavView;//导航栏
//@property (nonatomic,strong)HeadLineView *headLineView; //头视图
//@property (nonatomic,strong)HeadImageView *headImageView; //可将此View添加在TableView上





















@end
