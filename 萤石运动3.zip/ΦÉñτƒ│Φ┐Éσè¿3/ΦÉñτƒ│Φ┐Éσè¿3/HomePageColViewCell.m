//
//  HomePageColViewCell.m
//  萤石运动3
//
//  Created by Winner Zhu on 2016/12/1.
//  Copyright © 2016年 Winner Zhu. All rights reserved.
//

#import "HomePageColViewCell.h"
#import "CellModel.h"
#import "UIImageView+WebCache.h"


//统一UICollectionView页面上的字体
#define HomePageViewCellFontSize 11

#define TheDeviceWidth ([UIScreen mainScreen].bounds.size.width)
#define TheDeviceHeight ([UIScreen mainScreen].bounds.size.height)

#define HomePageViewCellImageWidth TheDeviceWidth - 10
#define HomePageViewCellImageHeight HomePageViewCellImageWidth/0.9066+20

#define HomePageViewCellControlSpacing 2   //UILabel之间的间距   未写入程序
#define HomePageViewCellMarginSpacing 5    //距离边缘的距离   未写入程序


/* MeinvImage size 由 cell size决定
 * #define HomePageViewCellWidth
 * #define HomePageViewCellHeight HomePageViewCellWidth /0.9066
 */

/*
 *width 680 * height750 ; 6/6s 4.7寸@2x 750*1344
 *width/height = 680/750 = 0.9066 → width = height *0.9066
 *
 */


@implementation HomePageColViewCell


- (void)awakeFromNib {
    
    [super awakeFromNib];
    // Initialization code

    
}


#pragma mark initWithFrame
-(instancetype)initWithFrame:(CGRect)frame{
    
    self = [super initWithFrame:frame];
    if (self) {
        
    // [self initSubView];
        
    }
    
    return self;
}




#pragma mark initSubView

-(void)initSubView{
    

}


#pragma mark set cellModel

-(void)setCellModel:(CellModel *)cellModel{
    
    _cellModel = cellModel;
    [self setNeedsLayout];
     
}



-(void)layoutSubviews{
    
    [super layoutSubviews];
    
    _dateL.text = _cellModel.dateInCell;
    _titleL0.text = _cellModel.titleStr0;
    _titleL1.text = _cellModel.titleStr1;
    _titleL2.text = _cellModel.titleStr2;
    _titleL3.text = _cellModel.titleStr3;

    NSURL *imageUrl = [NSURL URLWithString:_cellModel.imageUrl];
    [_meinvImage sd_setImageWithURL:imageUrl];
    
}





@end
