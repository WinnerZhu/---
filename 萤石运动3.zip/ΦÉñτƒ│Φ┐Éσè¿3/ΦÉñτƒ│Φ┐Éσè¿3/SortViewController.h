//
//  SortViewController.h
//  萤石运动3
//
//  Created by Winner Zhu on 2016/11/15.
//  Copyright © 2016年 Winner Zhu. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface SortViewController : UIViewController<UITableViewDelegate ,UITableViewDataSource>{
    
    NSArray *TheArrayForError;          
    NSArray *TheArrayForResults;
    
    int lastContentOffset;
    
}

- (instancetype)initWithIndex:(NSInteger)index title:(NSString *)title;

@property (nonatomic,strong) UITableView *tableViewInSortVC;

@property (nonatomic,copy) NSString *titleStr;

@property (nonatomic,copy) NSString *UrlString;  //First Networking

@property (nonatomic,assign ) NSInteger addingNum;

//测试初始化加载的数据如何做到与刷新后的数据共存;
@property (nonatomic,strong) NSMutableArray *TheGanhuoAfterEnum;
@property (nonatomic,strong) NSMutableArray *TheGanhuoCells;

@property (nonatomic,strong) NSMutableArray *cellArrayBeUsedToEnum;
@property (nonatomic,strong) NSMutableArray *ganhuoArrayBeUsedToEnum;

//根据已经显示的cell数量二次进行网络请求
@property (nonatomic,assign) NSInteger difference;

@property (nonatomic,strong) NSString *resendRequestUrl;

@property (nonatomic,assign) BOOL scrollDirectionUpDown;  // yes:鼠标向上移动(上) // no:鼠标向下移动(下)

@property (nonatomic,assign) BOOL sendRequestAgainOrNo;


@end






















