//
//  ShowMeinvPopUpView.h
//  萤石运动3
//
//  Created by Winner Zhu on 2016/12/15.
//  Copyright © 2016年 Winner Zhu. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Ganhuo.h"


@interface ShowMeinvPopUpView : UIView{
    
    UIView *backgroundView;
    UIImageView *popUpContainerView;
    
}


#pragma mark 初始化方法 with frame
-(instancetype)initWithFrame:(CGRect)frame;

#pragma mark 定义ganhuo
@property (nonatomic,strong) Ganhuo *ganhuoForImage;

#pragma mark 弹出PopUpView
-(void)showPopUpViewAnimate:(BOOL)animate;

#pragma mark 隐藏PopUpView
-(void)dismissPopUpViewAnimate:(BOOL)animte;

@end
