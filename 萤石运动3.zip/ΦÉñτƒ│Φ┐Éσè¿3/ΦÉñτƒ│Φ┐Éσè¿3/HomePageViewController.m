//
//  HomePageViewController.m
//  萤石运动3
//
//  Created by Winner Zhu on 2016/12/1.
//  Copyright © 2016年 Winner Zhu. All rights reserved.
//

#import "HomePageViewController.h"
#import "TFHpple.h"
#import "JSONModel.h"
#import "CellModel.h"
#import "HomePageColViewCell.h"
#import "IntradayGanhuoViewController.h"
#import "NavHeadTitleView.h"
#import "UploadPopUpView.h"
#import "SettingViewController.h"
#import "AlertPopUpView.h"


#define TheDeviceWidth ([UIScreen mainScreen].bounds.size.width)
#define TheDeviceHeight ([UIScreen mainScreen].bounds.size.height)
#define AnyColor(r,g,b,a) [UIColor colorWithRed:(r)/255.0 green:(g)/255.0 blue:(b)/255.0 alpha:(a)]


#define HomePageViewCellWidth TheDeviceWidth - 10     //左右留5
#define HomePageViewCellHeight HomePageViewCellWidth/0.9066+20
#define TheScrollThreshold 150
#define TheHeightOFcustomNavBar 64
#define DoveGrayColor [UIColor colorWithRed:113.0/255.0 green:113.0/255.0 blue:113.0/255.0 alpha:255.0/255.0]
#define fullScreen CGRectMake(0,0, TheDeviceWidth, TheDeviceHeight)

@interface HomePageViewController ()

@end

@implementation HomePageViewController


//static NSString *const cellId = @"cellId";
static NSString *const homecellxibId = @"homecellxib";


- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    //0.暂时使用自带NavigationBar → 隐藏系统自带NavigationBar
    self.navigationController.navigationBarHidden = YES;
    
    
    //1.创建UICollectionView
    [self creatCollectionView];
    
    
    //2.网络访问
    [self sendRequest];
    
    
    //3.创建数据实例(全局变量)
    _allCellModelArr  = [[NSMutableArray alloc]init];
    //_cellArrBeUsedEnum = [[NSMutableArray alloc]init];
    
    
    //4.创建自定义UINavigationBar(NavHeadTitleView)
    [self creatNavHeadTitleView];
    
    //5.设置 BOOL sendRequestAgainOrNo 初始状态
    _sendRequestAgainOrNo = NO;
    
    
    
}

#pragma mark 测试右滑返回效果
-(void)viewDidAppear:(BOOL)animated{
    if ([[[UIDevice currentDevice]systemVersion]floatValue] >= 7.0) {
        
        self.navigationController.interactivePopGestureRecognizer.enabled = NO;
    }
}



#pragma mark 创建UICollectionView
-(void)creatCollectionView{
    
    if (_homePageCollectionView == nil) {
        
        //1.创建布局类
        UICollectionViewFlowLayout *homePageFlowLayout = [[UICollectionViewFlowLayout alloc]init];
        
        //定义每个UICollectionCell大小
        homePageFlowLayout.itemSize = CGSizeMake(HomePageViewCellWidth, HomePageViewCellHeight);
        
        //定义每个UICollectionViewCell的纵向间距
        homePageFlowLayout.minimumLineSpacing = 5;
        
        //定义每个UICollectionViewCell的横向间距
        homePageFlowLayout.minimumInteritemSpacing = 5;
        
        //定义每个UICollectionViewCell的边距
        homePageFlowLayout.sectionInset = UIEdgeInsetsMake(30, 5, 5, 5);
        //height of UINavigationBar = 64; 64 -20 = 44
        
        
        //2.创建UICollectionView;留出状态栏的位置y=20
        _homePageCollectionView = [[UICollectionView alloc]initWithFrame:CGRectMake(0, 20 , TheDeviceWidth, TheDeviceHeight) collectionViewLayout:homePageFlowLayout ];
        
        _homePageCollectionView.delegate = self;
        _homePageCollectionView.dataSource = self;
        _homePageCollectionView.backgroundColor =  [UIColor whiteColor];

        //自适应大小
        _homePageCollectionView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;

        
        //3.注册cell以及ReusableView
        //[_homePageCollectionView registerClass:[HomePageColViewCell class] forCellWithReuseIdentifier:cellId ];
        
        //HomePageColViewCell.xib
        UINib *homePageCellNib = [UINib nibWithNibName:@"HomePageColViewCell" bundle:[NSBundle mainBundle]];
        [_homePageCollectionView registerNib:homePageCellNib forCellWithReuseIdentifier:homecellxibId];
       
        
    }
    
    [self.view addSubview:_homePageCollectionView];
    
    
    //add UIRefreshControl
    refreshControl = [[UIRefreshControl alloc]init];
    [_homePageCollectionView addSubview:refreshControl];
    refreshControl.tintColor = DoveGrayColor;
    
    [refreshControl addTarget:self action:@selector(refresh) forControlEvents:UIControlEventValueChanged];
    [[refreshControl.subviews objectAtIndex:0]setFrame:CGRectMake(0, 5, 0, 0)];
    //这样设置frame后刷新控件不会显示在画面中,隐形刷新操作
    
}


#pragma mark 刷新控件执行方法
-(void)refresh{
    
    if ((isLoading)) {
        
        [refreshControl endRefreshing];
        return;
    }
    
    isLoading = YES;
    [self sendRequest];
    [refreshControl endRefreshing];
    isLoading = NO;
    
}


#pragma mark 返回UICollectionViewCell内容
-(UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(nonnull NSIndexPath *)indexPath{
    
    //创建cell With Class
    /*
    HomePageColViewCell *cellInHomePage = [collectionView dequeueReusableCellWithReuseIdentifier:cellId forIndexPath:indexPath];
    */
    
    //创建cell With .xib
    HomePageColViewCell *cellInHomePage = [collectionView dequeueReusableCellWithReuseIdentifier:homecellxibId forIndexPath:indexPath];
    
    CellModel *cellModelFrArr = [[CellModel alloc]init];
    cellModelFrArr = self.allCellModelArr [indexPath.item];
    cellInHomePage.cellModel = cellModelFrArr;

    //二次网络请求
    _difference = self.allCellModelArr.count - indexPath.item;
    if (_difference == 8 && _scrollDirectionUpDown == YES ) { //1.检测到差值difference 2.监听滑动方向
        
        [self sendRequestAgain];
    }
    
    return cellInHomePage;

}



#pragma mark 选择一个cell时触发
-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    
    IntradayGanhuoViewController *IntradayViewC = [[IntradayGanhuoViewController alloc]init];
    CellModel *oneCellModel = [[CellModel alloc]init];
    oneCellModel = _allCellModelArr[indexPath.item];
    
    IntradayViewC.dateForUrl = oneCellModel.dateToIntraday;
    IntradayViewC.hidesBottomBarWhenPushed = YES;
    
    [self.navigationController pushViewController:IntradayViewC animated:YES];
    
}


#pragma mark 定义展示cell的个数
-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    
    return [_allCellModelArr count];
    
}

#pragma mark 定义展示的section的个数

-(NSInteger )numberOfSectionsInCollectionView:(UICollectionView *)collectionView{
    
    return 1;
}



#pragma mark 网络请求和数据加载
#pragma mark 数据加载方法
-(void)sendRequest{
    
    /*
     *注意对于url中的中文是无法解析的，需要进行url编码(指定编码类型为UTF-8),
     *另外注意url解码使用stringByRemovingPercentEncoding方法
     */
    
    //1.编码string,创建URL【创建URL】
    NSString *finalUrlStr;
    if (_sendRequestAgainOrNo == YES) {
        
        self.resendRequestUrl = [self.resendRequestUrl stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
        
        finalUrlStr = self.resendRequestUrl;
        
    }else{
        
        NSString *originalUrlStr = @"http://gank.io/api/history/content/20/1"; //每次获取25个妹子
        originalUrlStr = [originalUrlStr stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
        
        finalUrlStr = originalUrlStr;
        
    }
    NSURL *url = [NSURL URLWithString:finalUrlStr];
    
    
    //2.创建可变请求,设置请求方式为GET【创建请求】
    NSMutableURLRequest *requestForWelfare = [[NSMutableURLRequest alloc]initWithURL:url cachePolicy:NSURLRequestUseProtocolCachePolicy  timeoutInterval:5.0f];
    [requestForWelfare setHTTPMethod:@"GET"];
    
    
    //3.创建可变请求【创建链接】
    [NSURLConnection sendAsynchronousRequest:requestForWelfare queue:[NSOperationQueue mainQueue] completionHandler:^(NSURLResponse *respone,NSData *data,NSError *error ){
        
        if (!error) {
            
            [self loadData:data];
            [_homePageCollectionView reloadData];
            
        }else{
            AlertPopUpView *alertView = [[AlertPopUpView alloc]initWithFrame:fullScreen alertStr:@"请求超时啦"];
            [alertView showPopUpViewAnimate:YES];
        }
    }]; ////
    
}


#pragma nark 网络请求
-(void)loadData:(NSData *)data{
    
    //1.创建数组实例
    _cellArrBeUsedEnum = [[NSMutableArray alloc]init];
    
    
    //2.JSON序列化实例化
    NSError *error;
    NSDictionary *totalDic = [NSJSONSerialization JSONObjectWithData:data options:0 error:&error];
    ArrayForResults = (NSArray *)totalDic[@"results"];
    
    
    //3.枚举数组theArrayForResults中的item
    for (NSDictionary *JsonModelDic in ArrayForResults ) {
        
        JSONModel *JsonModel = [[JSONModel alloc]init];
        [JsonModel setValuesForKeysWithDictionary:JsonModelDic];
        
        NSString *JsonModelContent = JsonModel.content;
        
        //创建需要用到的数组字符串字典,均为局部变量
        NSMutableDictionary *cellModelDic = [[NSMutableDictionary alloc]init];
        NSMutableArray *titleArr = [[NSMutableArray alloc]init];
        NSString *imageUrl = [[NSString alloc]init];
        NSString *dateStr = JsonModel.publishedAt;
        NSString *dateInCell = [dateStr substringToIndex:10];
        NSString *dateToIntraday = [dateInCell stringByReplacingOccurrencesOfString:@"-" withString:@"/"];
        
        [cellModelDic setObject:dateInCell forKey:@"dateInCell"];
        [cellModelDic setObject:dateToIntraday forKey:@"dateToIntraday"];
        
        //HTML数据解析
        //创建一个NSData,获取html的Data数据,NSString转为NSdata √
        NSData *htmldata = [JsonModelContent dataUsingEncoding:NSUTF8StringEncoding];
        
        //使用第三方库TFHpple解析html数据
        TFHpple *xpathParser = [[TFHpple alloc]initWithHTMLData:htmldata];
        
        //根据标签进行过滤
        //p1.查找ul  <ul> - <li> - <a href=  target= </a> </li> - </ul>
        //直接搜索<li></li>中内容,将所有li整理成一个数组
        NSArray *liElem = [xpathParser searchWithXPathQuery:@"//li"];
        
        //枚举每个li
        for (TFHppleElement *eveLiElement in liElem) {
            
            //每个li中搜索a,将所有a整理成一个数组
            NSArray *aElement = [eveLiElement searchWithXPathQuery:@"//a"];
            
            //枚举每个a
            for (TFHppleElement *eveAElment in aElement) {
                
                //NSString *hrefUrl = [eveAElment objectForKey:@"href"];//这个并不需要,
                NSString *targetTitle = [eveAElment text];
                int i = 1; i++;
                
                if (targetTitle) {
                    
                    /*
                     *或许targetTitle需要先反编码,再添加
                     */
                    
                    NSString *BlackPointStr = @"· ";
                    targetTitle = [BlackPointStr stringByAppendingString:targetTitle];
                    
                    [titleArr addObject:targetTitle];
                    
                }//if
                
            }//for eveAElement
            
        }//for eveLiElement
        
        //p2.查找imgUrl <p> <img alt = src = 需要的东西 style = > </p>
        //直接搜索<p></p>中内容,将所有li整理成一个数组
        NSArray *pElem = [xpathParser searchWithXPathQuery:@"//p"];
        
        //枚举每个p
        for (TFHppleElement *eveP in pElem) {
            
            //每个p中搜索img,将所有a整理成一个数组
            NSArray *imgElem = [eveP searchWithXPathQuery:@"//img"];
            //枚举每个img
            for (TFHppleElement *eveImag in imgElem ) {
                
                imageUrl = [eveImag objectForKey:@"src"];
            }//for
            
        }//for
        
        //使用for循环创建titleStr,titleStr个数由n控制
        /*
         * n = number of UILabel in Cell = number of titleStr in cellModel
         * 可以定义为@property,由其他页面传递参数控制
         */
        int n = 4;  //上限为5,因为cellModel中只定义5个title
        for (int i = 0; i< n ; i ++) {
            
            NSString *titleStrPart1 = @"titleStr";
            NSString *titleStrPrat2 = [NSString stringWithFormat:@"%ld", (long)i];
            NSString *titleStrN = [titleStrPart1 stringByAppendingString:titleStrPrat2];
            
            [cellModelDic setObject:titleArr[i] forKey:titleStrN];
            
        }
        [cellModelDic setObject:imageUrl forKey:@"imageUrl"];
        
        
        CellModel *cellmodel = [[CellModel alloc]init];
        [cellmodel setValuesForKeysWithDictionary:cellModelDic];
        
        //在有刷新控件的情况下应该先添加到cellArrBeUsedEnum,在addobject到allCellModelArr
        [_cellArrBeUsedEnum addObject:cellmodel];
        
        
    }
    
    
    //4.将枚举得到的cellModel添加到枚举后的数组
    if (_sendRequestAgainOrNo == YES) {  //如果是again为yes,两个数组是加的关系
        
        [_allCellModelArr addObjectsFromArray: _cellArrBeUsedEnum];
        
    }else{   //否则,两个数组是等于的关系
        
        _allCellModelArr = _cellArrBeUsedEnum;
    }
    
}



#pragma mark 创建自定义导航栏
-(void)creatNavHeadTitleView{
    
    //此处需要一个页面上推而隐藏的UINavigationBar
    self.customNavBar = [[NavHeadTitleView alloc]initWithFrame:CGRectMake(0,0,TheDeviceWidth,TheHeightOFcustomNavBar)];
    self.customNavBar.nameTitle = @"干货美女集中营"; //后续可以更换为图片
    self.customNavBar.backTitleImage = @"adjh24.png";
    self.customNavBar.rightTitleImage = @"upload24.png";
    self.customNavBar.delegate = self;
    
    [self.view addSubview:self.customNavBar];
    
}


#pragma mark 导航栏左键

-(void)NavHeadToLeft{

    SettingViewController *settingVC = [SettingViewController new];
    UINavigationController *nav = [[UINavigationController alloc]initWithRootViewController:settingVC];
    [self presentViewController:nav animated:YES completion:nil];
    
}

#pragma mark 导航栏右键

-(void)NavHeadToRight{
    
    UploadPopUpView *thepopView = [[UploadPopUpView alloc] initWithFrame:self.view.bounds];
    [thepopView showPopUpViewAnimate:YES];
    
}




#pragma mark 滚动视图将要被拖拽
-(void)scrollViewWillBeginDragging:(UIScrollView *)scrollView{
    
    lastContentOffset = scrollView.contentOffset.y;
    
}


#pragma mark 滚动视图在滚动
-(void)scrollViewDidScroll:(UIScrollView *)scrollView{
    
    //int 纵向偏移量
    int contentOffsetY = scrollView.contentOffset.y;
    int currentContentOffsetY = scrollView.contentOffset.y;
    
    
    //通过纵向偏移量设置navigationBar的状态
    if (contentOffsetY <= TheScrollThreshold ) { // TheScrollThreshold 70
        //正在向上推≈回到顶部:不透明,有颜色;有title
        
        self.customNavBar.headBgview.alpha = 1;
        self.customNavBar.color = [UIColor blackColor];
        self.customNavBar.nameTitle = @"干货美女集中营";
        self.customNavBar.rightImageView = @"upload24.png";
        self.customNavBar.backTitleImage = @"adjh24.png";

        //隐藏黑线
        [self.navigationController.navigationBar setShadowImage:[UIImage new]];
        //状态栏字体黑色
        [UIApplication sharedApplication].statusBarStyle = UIStatusBarStyleDefault;
        
    }else{
        //向上推送越过阈值:透明,无色;无title
        
        self.customNavBar.headBgview.alpha = contentOffsetY/MAXFLOAT; // 0.3;//contentOffsety / 170;
        self.customNavBar.color = [UIColor clearColor];
        self.customNavBar.nameTitle = nil;
        self.customNavBar.rightImageView = @"";
        self.customNavBar.backTitleImage = @"";
        
        
    }
    
    
    //判断滚动方向
    if (currentContentOffsetY > lastContentOffset && currentContentOffsetY >= 50) {
        _scrollDirectionUpDown = YES;
        
    }else{
        _scrollDirectionUpDown = NO;
        
    }
    
}


#pragma mark - 再次发送求情
-(void)sendRequestAgain{
    
    //1.累加
    if (self.addingNum == 0) {
        self.addingNum = 1;
    }
    self.addingNum += 1;
    
    
    //2.生成resendRequestUrl  //http://gank.io/api/history/content/25/1
    
    NSString *part1 = @"http://gank.io/api/history/content/20/";
    NSString *part2 = [NSString stringWithFormat:@"%ld",(long)_addingNum];
    NSString *total = [part1 stringByAppendingString:part2];
    _resendRequestUrl = total;
    
    //3.设置sendRequestAgainOrNo 为 YES;
    //sendRequestAgainOrNo页面初始时为 NO,此处设为YES后,在该页面VC存在的周期一直为YES
    _sendRequestAgainOrNo = YES;
    
    
    //4.发送请求
    [self sendRequest];
    

}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/


@end
