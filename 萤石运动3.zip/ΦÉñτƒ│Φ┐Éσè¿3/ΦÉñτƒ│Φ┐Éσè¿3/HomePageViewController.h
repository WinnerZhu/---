//
//  HomePageViewController.h
//  萤石运动3
//
//  Created by Winner Zhu on 2016/12/1.
//  Copyright © 2016年 Winner Zhu. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "NavHeadTitleView.h"

@interface HomePageViewController : UIViewController<UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout,NavHeadTitleViewDelegate>{
    
    NSArray *ArrayForResults;
    int lastContentOffset;
    UIRefreshControl *refreshControl;
    BOOL isLoading;
    
}




@property (nonatomic,strong) NSMutableArray *allCellModelArr;  //存储所有collectionViewCell数据

@property (nonatomic,strong) NSMutableArray *cellArrBeUsedEnum;   //用于枚举过程的数据,暂时存储cell

@property (nonatomic,strong) UICollectionView *homePageCollectionView;

@property (nonatomic,strong) NavHeadTitleView *customNavBar;

@property (nonatomic,assign) NSInteger addingNum;

@property (nonatomic,assign) NSInteger difference;

@property (nonatomic,strong) NSString *resendRequestUrl;

@property (nonatomic,assign) BOOL scrollDirectionUpDown;  // yes:鼠标向上移动(上) // no:鼠标向下移动(下)

@property (nonatomic,assign) BOOL sendRequestAgainOrNo;  

@end
