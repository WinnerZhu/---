//
//  CellModel.h
//  LearningParserHTML
//
//  Created by Winner Zhu on 2016/11/30.
//  Copyright © 2016年 Winner Zhu. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CellModel : NSObject


/*
 *Test cellModelDic]{
 dateInCell = "2016-11-30";
 dateToIntraday = "2016/11/30";
 imageUrl = "http://ww1.sinaimg.cn/large/610dc034gw1fa9dca082pj20u00u0wjc.jpg";
 titleStr0 = "\U4e00\U4e2a\U5185\U7f6e\U5c0f\U5de7\U7684\U7ec8\U7aef\Uff0c\U8f93\U51fa App print \U4fe1\U606f\Uff0c\U8c03\U8bd5\U7684\U65f6\U5019\U5f88\U6709\U7528\U54e6\U3002";
 titleStr1 = "\U4e0b\U96e8\U6548\U679c\U7684\U4e0b\U62c9\U5237\U65b0";
 titleStr2 = "\U4eff\U6597\U9c7c\U6ed1\U52a8\U9a8c\U8bc1\U7801";
 titleStr3 = "\U6570\U5b57\U589e\U52a0\U52a8\U753b\U7684 TextView";
 titleStr4 = "\U5728\U7b56\U7565\U6a21\U5f0f\Uff08Strategy Pattern\Uff09\U4e2d\U5b9a\U4e49\U4e00\U7cfb\U5217\U7684\U7b97\U6cd5,\U628a\U5b83\U4eec\U4e00\U4e2a\U4e2a\U5c01\U88c5\U8d77\U6765, \U5e76\U4e14\U4f7f\U5b83\U4eec\U53ef\U76f8\U4e92\U66ff\U6362\U3002\U8fd9\U79cd\U7c7b\U578b\U7684\U8bbe\U8ba1\U6a21\U5f0f\U5c5e\U4e8e\U884c\U4e3a\U578b\U6a21\U5f0f\U3002";
 */


@property (nonatomic,strong) NSString *imageUrl;

@property (nonatomic,strong) NSString *dateToIntraday;

@property (nonatomic,strong) NSString *dateInCell;

@property (nonatomic,strong) NSString *titleStr0;

@property (nonatomic,strong) NSString *titleStr1;

@property (nonatomic,strong) NSString *titleStr2;

@property (nonatomic,strong) NSString *titleStr3;

@property (nonatomic,strong) NSString *titleStr4;


@end
