//
//  FavouriteViewController.m
//  萤石运动3
//
//  Created by Winner Zhu on 2016/11/9.
//  Copyright © 2016年 Winner Zhu. All rights reserved.
//

#import "FavouriteViewController.h"
#import "ShowGanhuoViewController.h"
#import "UITableView+EmptyData.h"
#import "SortAndFavTableViewCell.h"

#import "FavouriteGanhuo.h"

#define TheDeviceWidth ([UIScreen mainScreen].bounds.size.width)
#define TheDeviceHeight ([UIScreen mainScreen].bounds.size.height)


@interface FavouriteViewController ()

@end

@implementation FavouriteViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    // Do any additional setup after loading the view.
    self.navigationController.navigationBar.hidden = YES;
    
    //1.创建TableView
    [self creatTable];

    
}



#pragma mark - viewWillAppear方法中执行initialFavouriteGanhuoList方法;读取数据库中已经写入的数据
-(void)viewWillAppear:(BOOL)animated{
    
    [super viewWillAppear:animated];
    
    //1.initia
    [self initialFavouriteGanhuoList];
    
}


#pragma mark - 初始化Tool工具和数据库方法,并刷新列表
-(void)initialFavouriteGanhuoList{

    //之前设置cell hight不成功,可能是因为没有创建GanhuoCellsSourcE  ;;貌似真是这个原因
    GanhuoCellsSourcE = [[NSMutableArray alloc]init];
    
    //1.删除数组中的所有数据  [删除]？你确定是删除  ？
    [self.DatasourcE removeAllObjects];
    
    //2.测试是否创建FMDB封装工具
    if (!_Tool) {
        _Tool = [BQLDBTool instantiateTool];
        
    }
    
    //3.queryData
    NSArray *tempArray = [_Tool queryDataWith:FavouriteGanhuoFile];
    
    //4.枚举临时数组中的数据并存入DataSource
    for (NSDictionary *dic in tempArray) {
        
        FavouriteGanhuo *FavouriteGanhuoFrData = [FavouriteGanhuo modelWithDictionary:dic];
        [self.DatasourcE addObject:FavouriteGanhuoFrData];
        
        //存储tableViewCell
        SortAndFavTableViewCell *OneOFCell = [[SortAndFavTableViewCell alloc]init];
        [GanhuoCellsSourcE addObject:OneOFCell];
        
    }
    
    //5.刷新UITableView
    if (_TableViewForGanhuo) {
        [_TableViewForGanhuo reloadData];
    }
    
}


#pragma mark - 创建TableView
-(void)creatTable{

    _TableViewForGanhuo = [[UITableView alloc]initWithFrame:CGRectMake(0, -35, TheDeviceWidth, TheDeviceHeight - 0 ) style:UITableViewStyleGrouped ];
    _TableViewForGanhuo.delegate = self;
    _TableViewForGanhuo.dataSource =self;
    _TableViewForGanhuo.backgroundColor = [UIColor whiteColor];
    [_TableViewForGanhuo registerClass:[SortAndFavTableViewCell class] forCellReuseIdentifier:@"cel"];
    
    [self.view addSubview:_TableViewForGanhuo];
    
}


-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    //进入dui
    SortAndFavTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cel"];
    
    if (!cell ) {
        //进入dui
        cell = [[SortAndFavTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cel"];
    }
    
    cell.SortAndFavGanhuo = self.DatasourcE[indexPath.row];
    
    return cell;
    
}


#pragma mark - 重新设置单元格高度
-(CGFloat )tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{

    SortAndFavTableViewCell *cell = GanhuoCellsSourcE [indexPath.row]; //_GanhuoCellsSource
    cell.SortAndFavGanhuo = self.DatasourcE [indexPath.row];
    
    return cell.Height;
    //return 30;
}

#pragma mark - 返回每组行数 - 没有分组则为一个大组 - 无数据[提示语],需要添加UITableView的分类
-(NSInteger )tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{

    
    //无数据[提示语],需要添加UITableView的分类
    [tableView tableViewDisplayWitMsg:@"你倒是先收藏写干货啊~"ifNecessaryForRowCount:self.DatasourcE.count];
    
    return self.DatasourcE.count;

}



#pragma mark - 选择某行
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
 
    
    ShowGanhuoViewController *showganhuoViewController = [[ShowGanhuoViewController alloc]init];
    showganhuoViewController.FavGanhuoForNetw = self.DatasourcE[indexPath.row];
    showganhuoViewController.hidesBottomBarWhenPushed = YES;
    
    [self.navigationController pushViewController:showganhuoViewController animated:YES];
    
}


#pragma mark - cell编辑模式
-(void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath{

    if (editingStyle == UITableViewCellEditingStyleDelete ) { //删除模式
        
        //Step1.获取需要删除的ganhuo的index.row
        FavouriteGanhuo *GanhuoModel = self.DatasourcE[indexPath.row];
        
        //Step2.deleteData
        if ([_Tool deleteDataWith:FavouriteGanhuoFile Identifier:@"customid" IdentifierValue:[NSString stringWithFormat:@"%lld",GanhuoModel.customID]]) {
            
            [self.DatasourcE removeObjectAtIndex:indexPath.row];
        }
    }
    
    [_TableViewForGanhuo reloadData];
}


#pragma mark - 自定义左滑按钮文字
-(NSString *)tableView:(UITableView *)tableView titleForDeleteConfirmationButtonForRowAtIndexPath:(NSIndexPath *)indexPath{
    return @"想删除?";
}



#pragma mark - 这个应该是在测试数组是否存在,不存在就创建一个
-(NSMutableArray *)DatasourcE{
    
    if (!_DatasourcE) {
        _DatasourcE = [NSMutableArray arrayWithCapacity:1];
        
    }
    
    return _DatasourcE;
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
