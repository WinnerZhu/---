//
//  AlertPopUpView.m
//  萤石运动3
//
//  Created by Winner Zhu on 2016/12/10.
//  Copyright © 2016年 Winner Zhu. All rights reserved.
//


#import "AlertPopUpView.h"
#import "Masonry.h"


#define TheDeviceWidth ([UIScreen mainScreen].bounds.size.width)
#define TheDeviceHeight ([UIScreen mainScreen].bounds.size.height)
#define TheFontOFSizeInAlertLab1 18
#define TheFontOFSizeInAlertLab2 13
#define TheAlertPopUpViewHeight 0.15*TheDeviceHeight
#define TheAlertPopUpViewWidth  0.68*TheDeviceWidth


@implementation AlertPopUpView



#pragma mark 初始化方法
-(instancetype)initWithFrame:(CGRect)frame alertStr:(NSString *)alertStr{
    
    if (self = [super initWithFrame:frame]) {
        [self initLayouts:alertStr];
        
    }
    return self;
}



-(void)initLayouts:(NSString *)alertStr{
    
    if (self) {
        
        //1.背景View
        backgroundView = [[UIView alloc]initWithFrame:self.frame];
        backgroundView.backgroundColor = [UIColor colorWithRed:191.0/255.0 green:191.0/255.0 blue:191.0/255.0 alpha:0.3];//灰色半透明
        [self addSubview:backgroundView];

        
        //2.alertView
        alertPopUpView = [[UIView alloc]init];
        
        alertPopUpView.layer.masksToBounds = YES;
        alertPopUpView.layer.cornerRadius = 5.0f;
        alertPopUpView.backgroundColor = [UIColor whiteColor];
        [backgroundView addSubview:alertPopUpView];
        
        [alertPopUpView mas_makeConstraints:^(MASConstraintMaker *makeAlertPopV){
           
            makeAlertPopV.width.mas_equalTo(TheAlertPopUpViewWidth);
            makeAlertPopV.height.mas_equalTo(TheAlertPopUpViewHeight);
            makeAlertPopV.centerX.mas_equalTo(backgroundView.mas_centerX);
            makeAlertPopV.centerY.mas_equalTo(backgroundView.mas_centerY);
            
        }];
        
    }
    
    //3.alertLabel
    UILabel *alertLab1 = [[UILabel alloc]init];
    alertLab1.backgroundColor = [UIColor clearColor]; //无色
    alertLab1.font = [UIFont systemFontOfSize:TheFontOFSizeInAlertLab1 ];
    alertLab1.text = alertStr;

    
    [alertLab1 sizeToFit];  //效果不佳,将此行移入mas
    [alertPopUpView addSubview:alertLab1];
    
    [alertLab1 mas_makeConstraints:^(MASConstraintMaker *makeAlertLab1){
       
        makeAlertLab1.centerX.mas_equalTo(alertPopUpView.mas_centerX);
        makeAlertLab1.centerY.mas_equalTo(alertPopUpView.mas_centerY).offset(-10);
        
    }];
    
    
    UILabel *alertLab2 = [[UILabel alloc]init];
    alertLab2.backgroundColor = [UIColor clearColor]; //无色
    alertLab2.font = [UIFont systemFontOfSize:TheFontOFSizeInAlertLab2];
    
    if ([alertStr isEqualToString:@"上传成功"]) {
        alertLab2.text = @"牛是你牛!";
    }else if ([alertStr isEqualToString:@"上传失败"]){
        alertLab2.text = @"链接、描述、发布者昵称,缺一不可!";
    }else if ([alertStr isEqualToString:@"保存成功"]){
        alertLab2.text = @"羡慕你!又多了一个女朋友!";
    }else if ([alertStr isEqualToString:@"保存失败"]){
        alertLab2.text = @"说明你追女孩不用心!";
    }else if ([alertStr isEqualToString:@"请求超时啦"]){
        alertLab2.text = @"检查手机网络, 重启APP!";
    };
    
    
    
    [alertLab2 sizeToFit]; //效果不佳,将此行移入mas
    [alertPopUpView addSubview:alertLab2];
        
    [alertLab2 mas_makeConstraints:^(MASConstraintMaker * makeAlertLab2){
        
        makeAlertLab2.top.equalTo(alertLab1.mas_bottom).offset(5);
        makeAlertLab2.centerX.mas_equalTo(alertPopUpView.mas_centerX);
        
    }];

    
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW,
                    (int64_t)(1.5 * NSEC_PER_SEC)),
                   dispatch_get_main_queue(),
                   ^{
        
        [self dismissPopUpViewAnimate:YES];
    });
    
    
}


#pragma mark 弹出方法
-(void)showPopUpViewAnimate:(BOOL)animate{
    
    UIWindow *window = [[UIApplication sharedApplication] keyWindow];
    
    if (animate == YES) {
        
        [window addSubview:self];
        
        //动画效果
        alertPopUpView.transform = CGAffineTransformMakeScale(1.3, 1.3);
        alertPopUpView.alpha = 0;
        
        [UIView animateWithDuration:0.2 animations:^{
            
            alertPopUpView.transform = CGAffineTransformMakeScale(1.0, 1.0);
            alertPopUpView.alpha = 1;
        }];
        
    }else{
        
        [window addSubview:self];
    }
    
}
    

#pragma mark 隐藏方法
-(void)dismissPopUpViewAnimate:(BOOL)animte{
    
    if (animte) {
        
        [UIView animateWithDuration:0.3 animations:^{
            
            alertPopUpView.transform = CGAffineTransformMakeScale(1.3, 1.3);
            alertPopUpView.alpha = 0;

        } completion:^(BOOL finished) {
            if (finished) {
                [self removeFromSuperview];
            }
        }];
        
    }else{
        
        alertPopUpView.alpha = 0;
        [alertPopUpView removeFromSuperview];
        
    }
    
}



@end



