//
//  PickSortView.h
//  PopUpView2
//
//  Created by Winner Zhu on 2016/12/10.
//  Copyright © 2016年 Winner Zhu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PickSortView : UIPickerView<UIPickerViewDataSource,UIPickerViewDelegate>{
    

}


@property (nonatomic,strong) NSArray *sortArr;

@property (nonatomic,strong) NSString *selectedSort;


@end
