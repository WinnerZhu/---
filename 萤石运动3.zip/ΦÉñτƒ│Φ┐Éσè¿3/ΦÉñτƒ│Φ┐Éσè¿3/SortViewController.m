//
//  SortViewController.m
//  萤石运动3
//
//  Created by Winner Zhu on 2016/11/15.
//  Copyright © 2016年 Winner Zhu. All rights reserved.
//

#import "SortViewController.h"
#import "ShowGanhuoViewController.h"
#import "CCPNetworking.h"
#import "MBProgressHUD+ADD.h"
#import "Ganhuo.h"
#import "UITableView+EmptyData.h"
#import "OneOFGanhuoTableViewCell.h"
#import "AlertPopUpView.h"


#define TheDeviceWidth ([UIScreen mainScreen].bounds.size.width)
#define TheDeviceHeight ([UIScreen mainScreen].bounds.size.height)
#define AnyColor(r,g,b,a) [UIColor colorWithRed:(r)/255.0 green:(g)/255.0 blue:(b)/255.0 alpha:(a)]
#define TheScrollThreshold 150
#define fullScreen CGRectMake(0,0, TheDeviceWidth, TheDeviceHeight)

@interface SortViewController ()



@end


@implementation SortViewController

#pragma mark - 初始化方法
- (instancetype)initWithIndex:(NSInteger)index title:(NSString *)title
{
    self = [super init];
    if (self) {
        _titleStr = title;
        _addingNum = 1; //设置累加数起始数为1;
    }
    return self;
}


- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    //1.创建UITableView
    [self creatTabelView];
    
    //2.网络请求
    [self sendRequest];
    
    //3.创建数组实例(公共化)
    _TheGanhuoAfterEnum = [[NSMutableArray alloc]init];
    _TheGanhuoCells = [[NSMutableArray alloc]init];//设置cellhight不成功是因为没有创建这个数组;
    
    //4.设置 BOOL sendRequestAgainOrNo 初始状态
    _sendRequestAgainOrNo = NO;
    

}


#pragma mark 右滑返回效果
-(void)viewDidAppear:(BOOL)animated{
    
    //1.
//    if ([[[UIDevice currentDevice]systemVersion]floatValue] >= 7.0) {
//        self.navigationController.interactivePopGestureRecognizer.enabled = NO;
//    }
    
    //2.
    [_tableViewInSortVC reloadData];
    
}


#pragma mrak - 创建Tableview
-(void)creatTabelView{
    
     //UITableViewHeight = TheDeviceHeight -TabBatHeight(48)
    
    if (_tableViewInSortVC == nil) {
        
        self.tableViewInSortVC = [[UITableView alloc]initWithFrame:CGRectMake(0, 0 , TheDeviceWidth, TheDeviceHeight -64-49) style:UITableViewStyleGrouped];
        //49是UITarBar的高度;UISegmentedNavigationBarHeight=64
        
        _tableViewInSortVC.bounces = YES; //BOOL bounces;  设置UIScrollView是否需要弹簧效果
        _tableViewInSortVC.delegate = self;
        _tableViewInSortVC.dataSource =self;
        [_tableViewInSortVC registerClass:[OneOFGanhuoTableViewCell class]forCellReuseIdentifier:@"thecell"];
        _tableViewInSortVC.separatorStyle = UITableViewCellSeparatorStyleNone;
        _tableViewInSortVC.separatorColor = [UIColor blackColor];
        _tableViewInSortVC.showsVerticalScrollIndicator = NO;
        _tableViewInSortVC.backgroundColor = [UIColor whiteColor];
        
        UIView * headerView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, TheDeviceWidth, 1)];
        _tableViewInSortVC.tableHeaderView = headerView;
        
        [self.view addSubview:_tableViewInSortVC];
        
    }
    
}


#pragma mark - 返回cell内容
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    //1.创建cell
    OneOFGanhuoTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"thecell"];
    if (!cell) {
        cell = [[OneOFGanhuoTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"thecell"];
    }
    
    cell.ganhuo = self.TheGanhuoAfterEnum[indexPath.row];
    
    
    //2.二次网络请求
    _difference = self.TheGanhuoAfterEnum.count - indexPath.item;
    if (_difference == 10 && _scrollDirectionUpDown == YES) {
        
        [self sendRequestAgain];
    }
    
    return cell;
}


#pragma mark - UITableView代理方法
#pragma mark - 重新设置单元格高度

-(CGFloat )tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    OneOFGanhuoTableViewCell* cell = self.TheGanhuoCells[indexPath.row];
    cell.ganhuo = self.TheGanhuoAfterEnum[indexPath.row];
    
    return cell.Height;
    
}


#pragma mark - UITableView数据源方法
#pragma mark - 返回每组行数
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    //无数据[提示语],需要添加UITableView的分类
    [_tableViewInSortVC tableViewDisplayWitMsg:@"数据加载中...急毛线"ifNecessaryForRowCount:0];
    return self.TheGanhuoAfterEnum.count;
    
}

#pragma mark - 选择某行
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    ShowGanhuoViewController *showganhuoViewController = [[ShowGanhuoViewController alloc]init];
    showganhuoViewController.ganhuo = self.TheGanhuoAfterEnum[indexPath.row];
    showganhuoViewController.hidesBottomBarWhenPushed = YES;
    
    [self.navigationController pushViewController:showganhuoViewController animated:YES];
    
}


#pragma mark - 网络请求和数据加载
#pragma mark - 数据加载方法
-(void)loadData:(NSData *)data{
    
    //1.创建数组实例
    _ganhuoArrayBeUsedToEnum = [[NSMutableArray alloc]init];
    _cellArrayBeUsedToEnum = [[NSMutableArray alloc]init];
    
    
    //2.JSON序列化实例化
    /*json序列化
     *option = 0,返回NSDictionary或者NSarray
     */
    NSError *error;
    //将对象序列化为字典
    NSDictionary*TotalDictionary = [NSJSONSerialization JSONObjectWithData:data options:0 error:&error];
    TheArrayForResults = (NSArray *)TotalDictionary[@"results"];
    
    
    //3.枚举数组中的item
    for (NSDictionary *ganhuoFrSort in TheArrayForResults) {
        
        Ganhuo *ganhuo = [[Ganhuo alloc]init];
        [ganhuo setValuesForKeysWithDictionary:ganhuoFrSort];
        OneOFGanhuoTableViewCell *GanhuoCell = [[OneOFGanhuoTableViewCell alloc]init];
        
        [_ganhuoArrayBeUsedToEnum addObject:ganhuo];
        [_cellArrayBeUsedToEnum addObject:GanhuoCell];
    
    }
    
    
    //4.将枚举得到的ganhuo(数组)添加到枚举后的数组
    if (_sendRequestAgainOrNo == YES) {
        
        [_TheGanhuoAfterEnum addObjectsFromArray:_ganhuoArrayBeUsedToEnum];
        [_TheGanhuoCells addObjectsFromArray:_cellArrayBeUsedToEnum];

    }else{
        
        _TheGanhuoAfterEnum  = _ganhuoArrayBeUsedToEnum;
        _TheGanhuoCells = _cellArrayBeUsedToEnum;
        
    }
    
    //5.加载数据完成后刷新TableView
    [self.tableViewInSortVC reloadData];

    
}


#pragma mark - 网络请求方法
-(void)sendRequest{
    
    /*
     *注意对于url中的中文是无法解析的，需要进行url编码(指定编码类型为UTF-8),
     *另外注意url解码使用stringByRemovingPercentEncoding方法
     */
    
    
    //1.编码string,创建URL【创建URL】
    NSString *finalUrlStr;
    if (_sendRequestAgainOrNo == YES) {//_MJrefreshFooter.isRefreshing
        
        self.resendRequestUrl = [self.resendRequestUrl stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
        finalUrlStr = self.resendRequestUrl;
         
    }else{
        
        self.UrlString = [self.UrlString stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
        finalUrlStr = _UrlString;
        //※第一行必须两个self.UrlString,第二行必须将self.UrlString改成_UrlString才能实现全部页面的加载;什么鬼。
        
    }
    NSURL *url = [NSURL URLWithString:finalUrlStr];//_UrlString
    
    
    //2.创建可变请求,设置请求方式为GET【创建请求】
    NSMutableURLRequest *requestMut = [[NSMutableURLRequest alloc]initWithURL:url cachePolicy:0 timeoutInterval:5.0f];
    [requestMut setHTTPMethod:@"GET"];//设置为post请求,,傻逼 应该是GET请求
    
    
    //3.发送一个异步请求【创建连接】
    [NSURLConnection sendAsynchronousRequest:requestMut queue:[NSOperationQueue mainQueue] completionHandler:^(NSURLResponse *response , NSData *data , NSError *connectionError ){
        
        if (!connectionError ) {
            
            //0.先执行【数据加载】方法,再执行【刷新视图】方法
            //1.加载数据
            [self loadData:data];//self,自己执行loadData方法,参数是data
            //2.刷新视图
            [_tableViewInSortVC reloadData];
            
        }else{
            [[NSOperationQueue mainQueue]addOperationWithBlock:^{
            
                AlertPopUpView *alertView = [[AlertPopUpView alloc]initWithFrame:fullScreen alertStr:@"请求超时啦"];
                [alertView showPopUpViewAnimate:YES];
                
            }];
        }
    }];

}


#pragma mark - 再次发送求情
-(void)sendRequestAgain{
    
    //1.累加
    if (self.addingNum == 0) {
        self.addingNum = 1;
    }
    self.addingNum += 1;
    
    //2.生成resendRequestUrl
    NSMutableString * part1 = [NSMutableString stringWithString:_UrlString];
    NSString * part2 = [NSString stringWithFormat:@"%ld",(long)_addingNum];
    [part1 replaceCharactersInRange:NSMakeRange(_UrlString.length - 1,1) withString:part2];
    _resendRequestUrl = part1;
    
    //3.设置sendRequestAgainOrNo 为 YES;
    //sendRequestAgainOrNo页面初始时为NO,此处设为YES后,在该页面VC存在的周期一直为YES
    _sendRequestAgainOrNo = YES;
    
    //4.发送请求
    [self sendRequest];
    
}


#pragma mark - 根据scrollView代理方法监听滚动状态
#pragma mark 滚动视图将要被拖拽
-(void)scrollViewWillBeginDragging:(UIScrollView *)scrollView{
    
    lastContentOffset = scrollView.contentOffset.y;
}


#pragma mark 滚动视图在滚动
-(void)scrollViewDidScroll:(UIScrollView *)scrollView{
    
    //int 纵向偏移量
    int currentContentOffsetY = scrollView.contentOffset.y;
    
    //判断滚动方向
    if (currentContentOffsetY > lastContentOffset && currentContentOffsetY >= 50) {
        _scrollDirectionUpDown = YES;
        
    }else{
        _scrollDirectionUpDown = NO;
        
    }
    
}


#pragma mark - get方法
#pragma mark - get UrlStr //@"http://gank.io/api/data/iOS/20/1"
//分类数据:http://gank.io/api/data/数据类型/请求个数/第几页
-(NSString *)UrlString{
    
    NSString *part1 =  @"http://gank.io/api/data/";
    
    NSString *part2 = [NSString stringWithString:self.titleStr];
    
    NSString *part3 = @"/40/1";
    
    NSString *total = [part1 stringByAppendingString: [part2 stringByAppendingString:part3]];
    
    self.UrlString = total;
    
    return _UrlString;
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
