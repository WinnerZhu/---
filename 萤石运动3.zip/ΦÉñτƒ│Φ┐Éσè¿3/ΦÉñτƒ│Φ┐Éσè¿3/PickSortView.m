//
//  PickSortView.m
//  PopUpView2
//
//  Created by Winner Zhu on 2016/12/10.
//  Copyright © 2016年 Winner Zhu. All rights reserved.
//

#import "PickSortView.h"

@implementation PickSortView


-(instancetype)initWithFrame:(CGRect)frame{
    
    if (self = [super initWithFrame:frame]) {
        [self initialData];
        self.delegate =self;
        self.dataSource = self;
    }
    return self;
    
}

#pragma mark 设置初始数据
-(void)initialData{
    
    //NSString *filepath = [[NSBundle mainBundle]pathForResource:@"GanhuoSort.plist" ofType:nil];
    NSArray *arrayM = [NSArray arrayWithObjects:
                       @"Android",
                       @"iOS",
                       @"App",
                       @"瞎推荐",
                       @"前端",
                       @"福利",
                       @"休息视频",
                       @"拓展资源",
                       nil];
    
    self.sortArr = arrayM;
    
    //在这里设置pickerView数据的初始值
    [self pickerView:self didSelectRow:0 inComponent:1];
}

#pragma mark 一共多少列
-(NSInteger )numberOfComponentsInPickerView:(UIPickerView *)pickerView{
    
    return 1;
}

#pragma mark 每列多少行
-(NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component{
    
    return _sortArr.count;
}

#pragma mark 每列每行对应什么数据
-(NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component{
    
    NSString *oneOFSort = _sortArr[row];
    return oneOFSort;
}

#pragma mark 设置下方的数据刷新
-(void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component{
    
    _selectedSort = _sortArr[row];
}



@end
