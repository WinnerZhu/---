//
//  UploadPopUpView.m
//  TestPopupView
//
//  Created by Winner Zhu on 2016/12/7.
//  Copyright © 2016年 Winner Zhu. All rights reserved.
//

#import "UploadPopUpView.h"
#import "Masonry.h"
#import "PickSortView.h"
#import "AFNetworking.h"
#import "AlertPopUpView.h"


#define TheDeviceWidth ([UIScreen mainScreen].bounds.size.width)
#define TheDeviceHeight ([UIScreen mainScreen].bounds.size.height)
#define TheFontOFSizeInUITextField 14
#define TheFontOFSizeInBtnTitle 13
#define ThePopUpViewHeight 0.367*TheDeviceHeight
#define ThePopUpViewWidth  0.798*TheDeviceWidth
#define TheOneOfFivePopUpViewHeight 0.2*ThePopUpViewHeight
#define TheTextFieldOffset 0.25*TheOneOfFivePopUpViewHeight
#define TheIconSize 16
#define TheOffsetBetweenImageViewAndTextField -10
#define lightBlue [UIColor colorWithRed:169.0/255.0 green:159.0/255.0 blue:247.0/255.0 alpha:255.0/255.0]
#define fullScreen CGRectMake(0,0, TheDeviceWidth, TheDeviceHeight)


#pragma mark 自定义TextField
@interface customTextField  : UITextField

@end

@implementation customTextField

-(instancetype)initWithFrame:(CGRect)frame{
       if (self = [super initWithFrame:frame]) {
        [self setUpUI];
    }
    return self;
}

-(void)setUpUI{
    
    self.layer.masksToBounds = YES;
    self.layer.cornerRadius = 5.0f;
    
    self.layer.borderColor = [UIColor lightGrayColor].CGColor;
    self.layer.borderWidth = 1;
    self.font = [UIFont systemFontOfSize:TheFontOFSizeInUITextField];
    
    //设置placeholder

}

//设置placeholder
-(void)setPlaceholder:(NSString *)placeholder{
    
    NSMutableAttributedString *placeHolderStr = [[NSMutableAttributedString alloc]initWithString:placeholder];
    [placeHolderStr addAttribute:NSForegroundColorAttributeName
                           value:[UIColor lightGrayColor]
                           range:NSMakeRange(0, placeholder.length)];
    
    [placeHolderStr addAttribute:NSFontAttributeName
                           value:[UIFont boldSystemFontOfSize:13]
                           range:NSMakeRange(0, placeholder.length)];
    self.attributedPlaceholder = placeHolderStr;
    
}

//控制placeHolder的位置
-(CGRect)placeholderRectForBounds:(CGRect)bounds {
    
    CGRect inset = CGRectMake(bounds.origin.x+10, bounds.origin.y, bounds.size.width -10, bounds.size.height);//更好理解些
    
    return inset;
}

//控制显示文本的位置
-(CGRect)textRectForBounds:(CGRect)bounds{
    
    CGRect inset = CGRectMake(bounds.origin.x+10, bounds.origin.y, bounds.size.width -10, bounds.size.height);
    
    return inset;
}

//控制编辑文本的位置
-(CGRect)editingRectForBounds:(CGRect)bounds{
    
    CGRect inset = CGRectMake(bounds.origin.x +10, bounds.origin.y, bounds.size.width -10, bounds.size.height);
    
    return inset;
}
@end

///////////////////////////////////////////////////////////////////



#pragma mark popUpView
@interface UploadPopUpView ()<UITextFieldDelegate>{
    
    UIButton *publishBtn;
    UIButton *cancelBtn;
    
    customTextField *urlTextF;
    customTextField *descTextF;
    customTextField *whoTextF;
    
    UIView *backgroundView;
    UIView *popupView;
    
    PickSortView *pickerSortView;
    UITapGestureRecognizer *tap;
    
}

@end



@implementation UploadPopUpView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/


-(instancetype)initWithFrame:(CGRect)frame{
    
    
    if (self = [super initWithFrame:frame]) {
        
        //初始化界面
        [self loadSubViews];
        
        //添加键盘显示与消失通知
        [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(keyboardWillShow:) name:UIKeyboardWillShowNotification object:nil];
        
        [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(keyboardWillDismiss:) name:UIKeyboardWillHideNotification object:nil];
    
        
    }
    
    return self;
}



-(void)keyboardWillShow:(NSNotification *)notific{
    
    //给出案例VTingPromotView中的示例,其中centerView是我们的popupView
    //由于popupView整体偏上,应该不会收到键盘弹出的影响,所以此处不执行这些代码
    
    /*
     [UIView animateWithDuration:.2f animations:^{
     [centerView zxp_updateConstraints:^(ZXPAutoLayoutMaker *layout) {
     
     layout.widthValue(([UIScreen mainScreen].bounds.size.width - 70)); //不变
     layout.heightValue((175 * ([UIScreen mainScreen].bounds.size.width - 70))/250);//不变
     layout.xCenterByView(self,0); //不变
     layout.yCenterByView(self,0); //不变
     
     }];
     }];
     */
    
}


-(void)keyboardWillDismiss:(NSNotification *)notific{
    
    /*
     [UIView animateWithDuration:.2f animations:^{
     [centerView zxp_updateConstraints:^(ZXPAutoLayoutMaker *layout) {
     
     layout.widthValue(([UIScreen mainScreen].bounds.size.width - 70));
     layout.heightValue((175 * ([UIScreen mainScreen].bounds.size.width - 70))/250);
     layout.xCenterByView(self,0);
     layout.yCenterByView(self,-100); //上移100点
     
     }];
     }];
     */
    
}


-(void)loadSubViews{
    
    if (self) {
        
        //1.背景View
        backgroundView = [[UIView alloc]initWithFrame:self.frame];//self = UploadPopUpView
        backgroundView.backgroundColor = [UIColor colorWithRed:191.0/255.0 green:191.0/255.0 blue:191.0/255.0 alpha:0.3];//灰色半透明
        [self addSubview:backgroundView];
        
        
        //2.内容View
        popupView = [[UIView alloc]init];
        
        popupView.layer.masksToBounds = YES;
        popupView.layer.cornerRadius = 5.0f;
        popupView.backgroundColor = [UIColor whiteColor];
        [backgroundView addSubview:popupView];
        //12.8[backgroundView addSubview:popupView]必须写在这里,不然会有警告;奇葩
    
        //避免循环应用
        __weak typeof(backgroundView)weakBgView = backgroundView;

        [popupView mas_makeConstraints:^(MASConstraintMaker *makepopupView){
            makepopupView.top.equalTo(weakBgView).offset(124);
            makepopupView.centerX.equalTo(weakBgView.mas_centerX);
            makepopupView.height.mas_equalTo(ThePopUpViewHeight);
            makepopupView.width.mas_equalTo(ThePopUpViewWidth);
            
        }];
    }
    
    __weak typeof(popupView)weakPopView = popupView;
    
    
    //3分割线
    //3.1上分割线uplineView
    UIView *uplineView = [[UIView alloc]init];
    uplineView.backgroundColor = [UIColor lightGrayColor];
    [popupView addSubview:uplineView];
    
    [uplineView mas_makeConstraints:^(MASConstraintMaker * makeUpLineView){
        makeUpLineView.top.equalTo(weakPopView).offset(TheOneOfFivePopUpViewHeight);
        makeUpLineView.height.mas_equalTo(0.1);
        makeUpLineView.width.mas_equalTo(TheDeviceWidth);
        
    }];

    //3.2下分割线downlineView
    UIView *downlineView = [[UIView alloc]init];
    downlineView.backgroundColor = [UIColor lightGrayColor];
    [popupView addSubview:downlineView];
    
    [downlineView mas_makeConstraints:^(MASConstraintMaker *makeDownLineView){
       
        makeDownLineView.bottom.equalTo(weakPopView).offset(-TheOneOfFivePopUpViewHeight);
        makeDownLineView.height.mas_equalTo(0.1);
        makeDownLineView.width.mas_equalTo(TheDeviceWidth);
        
    }];
    
    
    
    //4.上部容器topView
    UIView *topView = [[UIView alloc]init];
    [popupView addSubview:topView];
    //※这里一定是先添加,再布局;这里有一点要必须注意下，添加约束前必须要把view添加到视图上。
    
    [topView mas_makeConstraints:^(MASConstraintMaker *makeTopView){
        
        makeTopView.top.equalTo(weakPopView).offset(0);
        makeTopView.right.equalTo(weakPopView).offset(0);
        makeTopView.left.equalTo(weakPopView).offset(0);
        makeTopView.height.mas_equalTo(TheOneOfFivePopUpViewHeight);  //fiveOneOFPopUpV这个值何时生成?
    }];
    

    __weak typeof(topView) weakTopView = topView;
    
    //4.1上部容器内容 取消按钮 cancelBtn
    cancelBtn = [[UIButton alloc]init];
    [cancelBtn setTitle:@"取消" forState:UIControlStateNormal];
    [cancelBtn setTitleColor:[UIColor blueColor] forState:UIControlStateNormal];
    [cancelBtn setTitleColor:lightBlue forState:UIControlStateHighlighted];
    cancelBtn.titleLabel.font = [UIFont systemFontOfSize:TheFontOFSizeInBtnTitle];
    [cancelBtn addTarget:self action:@selector(cancelPop) forControlEvents:UIControlEventTouchUpInside];
    [topView addSubview:cancelBtn];

    [cancelBtn mas_makeConstraints:^(MASConstraintMaker *makeCancelBtn){
        makeCancelBtn.top.equalTo(weakTopView).offset(0);
        makeCancelBtn.left.equalTo(weakTopView).offset(TheOneOfFivePopUpViewHeight/4);
        makeCancelBtn.bottom.equalTo(weakTopView).offset(0);
        
    }];
    
    
    //4.2上部容器内容 发布按钮 publishBtn
    publishBtn = [[UIButton alloc]init];
    [publishBtn setTitle:@"发布" forState:UIControlStateNormal];
    [publishBtn setTitleColor:[UIColor blueColor] forState:UIControlStateNormal];
    [publishBtn setTitleColor:lightBlue forState:UIControlStateHighlighted];
    publishBtn.titleLabel.font = [UIFont systemFontOfSize:TheFontOFSizeInBtnTitle];//13
    [publishBtn addTarget:self action:@selector(publishGanhuo) forControlEvents:UIControlEventTouchUpInside];
    [topView addSubview:publishBtn];

    [publishBtn mas_makeConstraints:^(MASConstraintMaker *makePublBtn){
        makePublBtn.top.equalTo(weakTopView).offset(0);
        makePublBtn.right.equalTo(weakTopView).offset(- TheOneOfFivePopUpViewHeight/4);
        makePublBtn.bottom.equalTo(weakTopView).offset(0);
        
    }];
    
    
    
    //5.TextField总容器 textFieldView
    UIView *textFieldView = [[UIView alloc]init];
    [popupView addSubview:textFieldView];
    
    [textFieldView mas_makeConstraints:^(MASConstraintMaker *makeTextFieldView){
    
        makeTextFieldView.top.equalTo(weakTopView.mas_bottom).offset(0);
        makeTextFieldView.left.equalTo(weakPopView).offset(0);
        makeTextFieldView.right.equalTo(weakPopView).offset(0);
        makeTextFieldView.height.mas_equalTo(TheOneOfFivePopUpViewHeight*3);
    
    }];
    
    
    //5.1 TextField分容器
    
    UIView *TFcontainer1 = [[UIView alloc]initWithFrame:CGRectMake(0, 0, ThePopUpViewWidth, TheOneOfFivePopUpViewHeight)];
    UIView *TFcontainer2 = [[UIView alloc]initWithFrame:CGRectMake(0, TheOneOfFivePopUpViewHeight, ThePopUpViewWidth, TheOneOfFivePopUpViewHeight)];
    UIView *TFcontainer3 = [[UIView alloc]initWithFrame:CGRectMake(0, TheOneOfFivePopUpViewHeight*2, ThePopUpViewWidth, TheOneOfFivePopUpViewHeight)];
    
    [textFieldView addSubview:TFcontainer1];
    [textFieldView addSubview:TFcontainer2];
    [textFieldView addSubview:TFcontainer3];

    //5.2 创建TextField
    //5.2.1 urlTF
    urlTextF = [[customTextField alloc]init];
    urlTextF.placeholder = @"输入/粘贴分享链接";
    urlTextF.delegate = self;
    [TFcontainer1 addSubview:urlTextF];
    
    [urlTextF mas_makeConstraints:^(MASConstraintMaker *makeUrlTextF){
        
        //TextField的宽高统一定义
        makeUrlTextF.width.mas_equalTo(ThePopUpViewWidth - TheOneOfFivePopUpViewHeight - 10);
        makeUrlTextF.height.mas_equalTo(0.66 * TheOneOfFivePopUpViewHeight);
        //TextField在容器中的横向偏移量统一定义
        makeUrlTextF.centerX.mas_equalTo(TFcontainer1).offset(TheTextFieldOffset);
        makeUrlTextF.centerY.mas_equalTo(TFcontainer1);
    }];

    //5.2.2 descTF
    descTextF = [[customTextField alloc]init];
    descTextF.delegate = self;
    descTextF.placeholder  = @"输入分享描述";
    [textFieldView addSubview:descTextF];
    
    [descTextF mas_makeConstraints:^(MASConstraintMaker *makeDescTextF){
       
        makeDescTextF.width.mas_equalTo(urlTextF);
        makeDescTextF.height.mas_equalTo(urlTextF);
        makeDescTextF.centerX.mas_equalTo(TFcontainer2).offset(TheTextFieldOffset);
        makeDescTextF.centerY.mas_equalTo(TFcontainer2);
    }];
    
    //5.2.3 whoTF
    whoTextF = [[customTextField alloc]init];
    whoTextF.delegate = self;
    whoTextF.placeholder  = @"输入发布者昵称";
    [TFcontainer3 addSubview:whoTextF];
    
    [whoTextF mas_makeConstraints:^(MASConstraintMaker *makeWhoTextF){
        
        makeWhoTextF.width.mas_equalTo(urlTextF);
        makeWhoTextF.height.mas_equalTo(urlTextF);
        makeWhoTextF.centerX.mas_equalTo(TFcontainer3).offset(TheTextFieldOffset);
        makeWhoTextF.centerY.mas_equalTo(TFcontainer3);
    }];

    //5.3创建UIImageView
    UIImageView *urlImage = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"link241.png"]];
    UIImageView *descImage = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"desc241.png"]];
    UIImageView *whoImage = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"who241.png"]];
    
    [TFcontainer1 addSubview:urlImage];
    [TFcontainer2 addSubview:descImage];
    [TFcontainer3 addSubview:whoImage];
    
    [urlImage mas_makeConstraints:^(MASConstraintMaker *makeUrlImage){
        makeUrlImage.size.mas_equalTo(CGSizeMake(TheIconSize, TheIconSize));
        makeUrlImage.right.equalTo(urlTextF.mas_left).offset(TheOffsetBetweenImageViewAndTextField);
        makeUrlImage.centerY.mas_equalTo(TFcontainer1);
    }];
    
    [descImage mas_makeConstraints:^(MASConstraintMaker *makeDescImage){
        makeDescImage.size.mas_equalTo(CGSizeMake(TheIconSize, TheIconSize));
        makeDescImage.right.equalTo(descTextF.mas_left).offset(TheOffsetBetweenImageViewAndTextField);
        makeDescImage.centerY.mas_equalTo(TFcontainer2);
    }];
    
    [whoImage mas_makeConstraints:^(MASConstraintMaker *makeWhoImage){
        makeWhoImage.size.mas_equalTo(CGSizeMake(TheIconSize, TheIconSize));
        makeWhoImage.right.equalTo(whoTextF.mas_left).offset(TheOffsetBetweenImageViewAndTextField);
        makeWhoImage.centerY.mas_equalTo(TFcontainer3);
    }];
    
    
    //6.PikerView容器[UIButton]
    UIButton* pickerViewContainer = [[UIButton alloc]init];
    [pickerViewContainer addTarget:self action:@selector(pickerViewAppear) forControlEvents:UIControlEventTouchUpInside];
    [popupView addSubview:pickerViewContainer];
    
    
    [pickerViewContainer mas_makeConstraints:^(MASConstraintMaker *makePicRV){
        makePicRV.size.mas_equalTo(CGSizeMake(ThePopUpViewWidth, TheOneOfFivePopUpViewHeight));
        makePicRV.bottom.equalTo(popupView.mas_bottom).offset(0);
        makePicRV.left.equalTo(popupView.mas_left).offset(0);
    }];
    
    
    //6.1创建tag icon
    UIImageView *tagImage = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"tag241.png"]];
    [pickerViewContainer addSubview:tagImage];

    [tagImage mas_makeConstraints:^(MASConstraintMaker *makeTag){
        makeTag.size.mas_equalTo(CGSizeMake(TheIconSize, TheIconSize));
        makeTag.right.equalTo(whoImage).offset(0);
        makeTag.centerY.mas_equalTo(pickerViewContainer);
    }];
    
    
    //6.2创建UILabel
    self.pickerResLabel = [[UILabel alloc]init];
    _pickerResLabel.font = [UIFont systemFontOfSize:TheFontOFSizeInUITextField];
    _pickerResLabel.textColor = [UIColor blackColor];//明确的说跟icon颜色一致
    _pickerResLabel.textAlignment = NSTextAlignmentLeft;
    [pickerViewContainer addSubview:_pickerResLabel];
    
    [_pickerResLabel mas_makeConstraints:^(MASConstraintMaker *makePicResLabel){
        
        makePicResLabel.width.mas_equalTo(urlTextF);
        makePicResLabel.height.mas_equalTo(TheOneOfFivePopUpViewHeight);
        makePicResLabel.centerX.mas_equalTo(pickerViewContainer).offset(TheTextFieldOffset);
        makePicResLabel.centerY.mas_equalTo(pickerViewContainer);
        
    }];
    
    
    //7 PickerView出现
    pickerSortView = [[PickSortView alloc]initWithFrame:CGRectMake(0,TheOneOfFivePopUpViewHeight, ThePopUpViewWidth, 4*TheOneOfFivePopUpViewHeight)];
    pickerSortView.backgroundColor = [UIColor whiteColor];
    _pickerResLabel.text = pickerSortView.sortArr[0];//设置初始值
    
}


#pragma mark ButtonClick - cancelBtn
-(void)cancelPop{

    if (_pickerViewWhetherAppear == YES) { //[状态:返回]
        
        [pickerSortView removeFromSuperview];
        _pickerViewWhetherAppear = NO;
        
        [publishBtn setTitle:@"发布" forState:UIControlStateNormal];
        [cancelBtn setTitle:@"取消" forState:UIControlStateNormal];
        
    }else{  //[状态:取消]
        
          [self dismissPopUpViewAnimate:YES];
    }
}


#pragma mark ButtonClick - publishBtn
-(void)publishGanhuo{

    if (_pickerViewWhetherAppear == YES) {//[状态:确定]

        [pickerSortView removeFromSuperview];
        _pickerViewWhetherAppear = NO;
        _pickerResLabel.text = pickerSortView.selectedSort;
        
        [publishBtn setTitle:@"发布" forState:UIControlStateNormal];
        [cancelBtn setTitle:@"取消" forState:UIControlStateNormal];
        
    }else{//[状态:发布] [发布成功或失败:弹出警示框]
        
        NSString *urlStrFrTextF = urlTextF.text;
        NSString *descStrFrTextF = descTextF.text;
        NSString *whoStrFrTextF= whoTextF.text;
        NSString *sortStrFrLab = pickerSortView.selectedSort;
        
        if (urlStrFrTextF.length != 0 && descStrFrTextF.length != 0 && whoStrFrTextF.length != 0) {
        
            NSDictionary *parameters = @{
                                         @"url":urlStrFrTextF,
                                         @"desc":descStrFrTextF,
                                         @"who":whoStrFrTextF,
                                         @"type":sortStrFrLab,
                                         @"debug":@"ture"
                                         };
            
            [self uploadGanhuo:parameters];
            
        }else{
            
            NSString *sendAlertStr = [NSString stringWithFormat:@"上传失败"];
            AlertPopUpView *alertInUploadPopV = [[AlertPopUpView alloc]initWithFrame:fullScreen
                                                                            alertStr: sendAlertStr ];
            [alertInUploadPopV showPopUpViewAnimate:YES ];
            
        }//end else
    }//end else
}


#pragma mark ButtonClick - pickerViewContainer
-(void)pickerViewAppear{
    
    [popupView addSubview:pickerSortView];
    
    _pickerViewWhetherAppear = YES;
    [publishBtn setTitle:@"确定" forState:UIControlStateNormal];
    [cancelBtn setTitle:@"返回" forState:UIControlStateNormal];
    
}


#pragma mark 弹出PopUpView
-(void)showPopUpViewAnimate:(BOOL)animate{
    
    UIWindow *window = [[UIApplication sharedApplication] keyWindow];
    
    if (animate == YES) {
        
        [window addSubview:self];
        
        //动画效果
        popupView.transform = CGAffineTransformMakeScale(1.3, 1.3);
        popupView.alpha = 0;
        
        [UIView animateWithDuration:0.2 animations:^{
            
            popupView.transform = CGAffineTransformMakeScale(1.0, 1.0);
            popupView.alpha = 1;
        }];
        
    }else{
        
        [window addSubview:self];
    }
}


#pragma mark 隐藏PopUpView
-(void)dismissPopUpViewAnimate:(BOOL)animte{
    
    [self endEditing:YES];
    
    if (animte) {
        
        [UIView animateWithDuration:0.3 animations:^{
            
            popupView.transform = CGAffineTransformMakeScale(1.3, 1.3);
            popupView.alpha = 0;
            
        } completion:^(BOOL finished) {
            
            if (finished) {
                [self removeFromSuperview];
            }
        }];
    }else{
        
        popupView.alpha = 0;
        [popupView removeFromSuperview];
    }
}



/*
-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    
    UITouch *touch = [touches anyObject];
    if (![touch.view isEqual:_pickerViewContainer]){

        NSLog(@"[Test touch in pickerViewContainer]");

        
    }//end if
}
*/


#pragma mark AFNetworking 数据上传
-(void)uploadGanhuo:(NSDictionary *)parametersDic{
    
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    NSString *urlStr = @"https://gank.io/api/add2gank";
    
    [manager  POST:urlStr parameters:parametersDic
          progress:^(NSProgress *_Nonnull uploadProgress){
              //上传进度
          }success:^(NSURLSessionDataTask *_Nonnull task , id _Nullable responseObject){
              
              NSString *sendAlertStr = [NSString stringWithFormat:@"上传成功"];
              AlertPopUpView *alertPopView = [[AlertPopUpView alloc]initWithFrame:fullScreen  alertStr:sendAlertStr];
              [alertPopView showPopUpViewAnimate:YES];
              
          }failure:^(NSURLSessionDataTask *_Nullable task, NSError *_Nonnull error){

          }];
}



@end



