//
//  ShowMeinvPopUpView.m
//  萤石运动3
//
//  Created by Winner Zhu on 2016/12/15.
//  Copyright © 2016年 Winner Zhu. All rights reserved.
//

#import "ShowMeinvPopUpView.h"
#import "Masonry.h"
#import "AlertPopUpView.h"


#define TheDeviceWidth ([UIScreen mainScreen].bounds.size.width)
#define TheDeviceHeight ([UIScreen mainScreen].bounds.size.height)
#define fullScreen CGRectMake(0,0, TheDeviceWidth, TheDeviceHeight)


@implementation ShowMeinvPopUpView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/


-(instancetype)initWithFrame:(CGRect)frame{
    
    
    if (self = [super initWithFrame:frame]) {
        
        //初始化界面
        [self layoutSubviews];   //[self loadSubViews];
        
        //添加手势
        [self addgesture];
        
    }
    
    return self;
}



-(void)layoutSubviews{
    
    if (self) {
        
        //1.背景View
        backgroundView = [[UIView alloc]initWithFrame:self.frame];//self = UploadPopUpView
        backgroundView.backgroundColor = [UIColor colorWithRed:191.0/255.0 green:191.0/255.0 blue:191.0/255.0 alpha:0.3];//灰色半透明
        [self addSubview:backgroundView];
        
        
        //2.0 meinv container view
        popUpContainerView = [[UIImageView alloc]init];
    
        popUpContainerView.contentMode = UIViewContentModeScaleAspectFill;//设置内容模式为缩放填充
        popUpContainerView.clipsToBounds = YES;
        popUpContainerView.userInteractionEnabled = YES;//设置该属性为YES,否则无法接受手势操作
        
        //3.从model中获得图片
        NSURL *meinvImageUrl = [NSURL URLWithString:_ganhuoForImage.url];
        NSData *meinvImageData = [NSData dataWithContentsOfURL:meinvImageUrl];
        UIImage *meinvImage = [UIImage imageWithData:meinvImageData];
        
        
        //4.根据图片尺寸设置PopUpView大小
        
        CGFloat popUpViewWidth = TheDeviceWidth;
        CGFloat popUpViewHeidht;
        
        if (meinvImage.size.width) {
            
            popUpViewHeidht = meinvImage.size.height/meinvImage.size.width *popUpViewWidth;
        }
    
        CGSize meinvPopViewSize = CGSizeMake(popUpViewWidth, popUpViewHeidht);
        
        
        //5.布局
        [backgroundView addSubview:popUpContainerView];
        
        [popUpContainerView mas_makeConstraints:^(MASConstraintMaker *makePopUpView){
            
            makePopUpView.centerX.equalTo(backgroundView.mas_centerX);
            makePopUpView.centerY.equalTo(backgroundView.mas_centerY);
            makePopUpView.size.mas_equalTo(meinvPopViewSize);
            
        }];
        
        
        //6.添加图片到ImageView,添加美女图片到容器;
        popUpContainerView.image = meinvImage;

    }//end if
}



#pragma mark 添加手势
-(void)addgesture{
    
    /*添加点按手势 */ //---回到上一界面
    UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(JustTap:)];
    tapGesture.numberOfTapsRequired = 1;//设置点按次数,默认为1,注意在iOS中很少用双击操作
    tapGesture.numberOfTouchesRequired = 1;//点按的手指数
    [self addGestureRecognizer:tapGesture];
    
    
    /*添加捏合手势 */  //---放大或缩小图片
    UIPinchGestureRecognizer *pinchGesture = [[UIPinchGestureRecognizer alloc]initWithTarget:self action:@selector(PinchTheImageView:)];
    [self addGestureRecognizer:pinchGesture];
    
    
    /*添加拖动手势*/  //---放大图片后移动图片所显示的位置 (※是放大图片后才执行的时候)
    UIPanGestureRecognizer *panGesture = [[UIPanGestureRecognizer alloc]initWithTarget:self action:@selector(PanTheImageView:)];
    [self addGestureRecognizer:panGesture];
    
    
    /*添加长按手势*/  //长按保存图片到本地
    UILongPressGestureRecognizer *longPressGesture = [[UILongPressGestureRecognizer alloc]initWithTarget:self action:@selector(longPressImage:)];
    longPressGesture.minimumPressDuration = 0.5;
    [self addGestureRecognizer:longPressGesture];
    
    
}


#pragma mark 各个手势操作
#pragma mark 点按 - 回到上一界面
-(void)JustTap:(UITapGestureRecognizer *)gesture{
    
    //回到上一界面
    [self dismissPopUpViewAnimate:YES];
    
}


#pragma mark 捏合 - 放大或缩小图片
-(void)PinchTheImageView:(UIPinchGestureRecognizer *)gesture{
    
    if (gesture.state == UIGestureRecognizerStateChanged) {
        //捏合手势中scale属性记录缩放比例
        popUpContainerView.transform = CGAffineTransformMakeScale(gesture.scale, gesture.scale);
        
    }else if (gesture.state == UIGestureRecognizerStateEnded){ //结束后恢复
        
        [UIView animateWithDuration:0.5 animations:^{
            popUpContainerView.transform = CGAffineTransformIdentity; //取消一切形变
        }];
    }//end else
    
}


#pragma mark 拖动 - 拖动图片
-(void)PanTheImageView:(UIPanGestureRecognizer *)gesture{
    
    if (gesture.state == UIGestureRecognizerStateChanged) {
        
        //利用拖动手势(PanGestureRecognizer)的translationInView:方法,取得在相对指定视图(这里是控制器根视图)的移动
        //注意:translationInView:方法,只有在以UIPanGestureRecognizer为参数的方法中才能调用。
        
        CGPoint translation = [gesture translationInView:self];
        popUpContainerView.transform = CGAffineTransformMakeTranslation(translation.x, translation.y);
        
    } else if (gesture.state == UIGestureRecognizerStateEnded){
        
        [UIView animateWithDuration:0.5 animations:^{
            popUpContainerView.transform = CGAffineTransformIdentity;
        }];
    }//end else
}


#pragma mark 长按 - 保存图片到相册
-(void)longPressImage:(UILongPressGestureRecognizer *)gesture{
    
    if (gesture.state == UIGestureRecognizerStateBegan) {
        
        /*保存图片到本地*/
         NSURL *MeinvImageUrl = [NSURL URLWithString:_ganhuoForImage.url];
         NSData *MeinvImageData = [NSData dataWithContentsOfURL:MeinvImageUrl];
         UIImage *MeinvImage = [UIImage imageWithData:MeinvImageData];
        
        UIImageWriteToSavedPhotosAlbum(MeinvImage,self,@selector(image:didFinishSavingWithError:contentInfo:),nil);
        
    }
}


#pragma mark - 保存图片成功提示语
-(void)image:(UIImage *)image didFinishSavingWithError:(NSError *)error contentInfo:(void *)contextInfo{
   
    if (error != NULL) {
        AlertPopUpView *successAlert = [[AlertPopUpView alloc]initWithFrame:fullScreen alertStr:@"保存失败"];
        [successAlert showPopUpViewAnimate:YES];
        
    }else{
        AlertPopUpView *successAlert = [[AlertPopUpView alloc]initWithFrame:fullScreen alertStr:@"保存成功"];
        [successAlert showPopUpViewAnimate:YES];
        
    }
    
}


#pragma mark set方法
-(void)setGanhuoForImage:(Ganhuo *)ganhuoForImage{
    
    _ganhuoForImage = ganhuoForImage;
    
}


#pragma mark 弹出PopUpView
-(void)showPopUpViewAnimate:(BOOL)animate{
    
    UIWindow *window = [[UIApplication sharedApplication] keyWindow];
    
    if (animate == YES) {
        
        [window addSubview:self];
        
        //动画效果
        popUpContainerView.transform = CGAffineTransformMakeScale(1.3, 1.3);
        popUpContainerView.alpha = 0;
        
        [UIView animateWithDuration:0.2 animations:^{
            
            popUpContainerView.transform = CGAffineTransformMakeScale(1.0, 1.0);
            popUpContainerView.alpha = 1;
            
        }];
        
    }else{
        
        [window addSubview:self];
    }
}


#pragma mark 隐藏PopUpView
-(void)dismissPopUpViewAnimate:(BOOL)animte{
    
    [self endEditing:YES];
    
    if (animte) {
        
        [UIView animateWithDuration:0.3 animations:^{
            
            popUpContainerView.transform = CGAffineTransformMakeScale(1.3, 1.3);
            popUpContainerView.alpha = 0;
            
        } completion:^(BOOL finished) {
            
            if (finished) {
                [self removeFromSuperview];
            }
        }];
    }else{
        
        popUpContainerView.alpha = 0;
        [popUpContainerView removeFromSuperview];
    }
}







@end
