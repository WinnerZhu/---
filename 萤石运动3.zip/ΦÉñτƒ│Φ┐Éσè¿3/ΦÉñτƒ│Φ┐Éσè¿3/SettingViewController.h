//
//  SettingViewController.h
//  萤石运动3
//
//  Created by Winner Zhu on 2016/12/18.
//  Copyright © 2016年 Winner Zhu. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "NavHeadTitleView.h"


@interface SettingViewController : UIViewController<UITableViewDelegate,UITableViewDataSource,NavHeadTitleViewDelegate>{
    
    NSArray *dataArr1;
    NSArray *dataArr2;
    
    NSMutableArray *aboutAnvVersionArr;
    NSMutableArray *feedbackArr;
    
    NSMutableArray *titleCellsArr;
    NSMutableArray *groupArrary;
    
}


@property (nonatomic,strong) UITableView *settingTable;

@property (nonatomic,strong)NavHeadTitleView *NavView;//导航栏



@end
