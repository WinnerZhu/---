//
//  GanhuoGroup.h
//  萤石运动3
//
//  Created by Winner Zhu on 16/8/30.
//  Copyright © 2016年 Winner Zhu. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Ganhuo.h"



@interface GanhuoGroup : NSObject

#pragma mark 组名
@property (nonatomic,copy) NSString *groupname;

#pragma mark 组内ganhuo们
@property (nonatomic,strong) NSMutableArray *ganhuos;


#pragma mark 带参数构造函数
-(GanhuoGroup *)initWithGroupname:(NSString *)groupname andGanhuos:(NSMutableArray *)ganhuos;

#pragma mark 静态初始化方法
+(GanhuoGroup *)initWithGroupname:(NSString *)groupname andGanhuos:(NSMutableArray *)ganhuos;








@end
