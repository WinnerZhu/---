//
//  FavouriteViewController.h
//  萤石运动3
//
//  Created by Winner Zhu on 2016/11/9.
//  Copyright © 2016年 Winner Zhu. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SortAndFavTableViewCell.h"

#import "BQLDBTool.h"

@class FavouriteGanhuo;


@interface FavouriteViewController : UIViewController<UITableViewDelegate,UITableViewDataSource>{
    
    //1.FMDB
    //BQLDBTool *Tool;
    
    //2.将各条数据存在可变数组中
    //NSMutableArray *DataSource;
    
    //3.UITableView For Sort And Favourite Ganhuo
    //UITableView *TableViewForGanhuo;
    
    //4.存储cell,用预计算高度
    NSMutableArray *GanhuoCellsSourcE;
    
}

#pragma mark FMDB
@property (nonatomic,strong) BQLDBTool *Tool;

#pragma mark UITableView For Sort And Favourite Ganhuo
@property (nonatomic,strong) UITableView *TableViewForGanhuo;

#pragma mark 将TableViewCell存在数组中用于计算cell高度
//@property (nonatomic,strong) NSMutableArray *GanhuoCellsSource; //存储cell,用预计算高度

#pragma mark 将各条数据存在可变数组中
@property (nonatomic,strong) NSMutableArray *DatasourcE;



@end







































