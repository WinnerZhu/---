//
//  NavHeadTitleView.m
//  萤石运动3
//
//  Created by Winner Zhu on 16/9/24.
//  Copyright © 2016年 Winner Zhu. All rights reserved.
//

#import "NavHeadTitleView.h"

#define TheDeviceWidth ([UIScreen mainScreen].bounds.size.width)
#define TheDeviceHeight ([UIScreen mainScreen].bounds.size.height)
#define NavigationBarFontSize 17


@interface NavHeadTitleView ()

@property (nonatomic,strong)UILabel *label;
@property (nonatomic,strong)UIButton *backBtn;
@property (nonatomic,strong)UIButton *rightBtn;

@end




@implementation NavHeadTitleView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

//inti
-(instancetype)initWithFrame:(CGRect)frame{
    
    if (self = [super initWithFrame:frame]) {
        
        //headBgview(UIImageView)//////////////////////////////////////////
        self.headBgview = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, frame.size.width, frame.size.height)];
        self.headBgview.backgroundColor = [UIColor whiteColor];// whiteColor
        self.headBgview.image = [UIImage imageNamed:@"nav－-bar"];  //@"nav--bar"
        //隐藏黑线
        self.headBgview.alpha = 0;
        [self addSubview:self.headBgview];
        
        
        //LeftBtn(UIButton)/////////////////////////////////////////////////////
        self.backBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        self.backBtn.backgroundColor = [UIColor clearColor];
        self.backBtn.frame = CGRectMake(15, 30, 25, 25);
        [self.backBtn addTarget:self action:@selector(backBtnClick) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:self.backBtn];
        
        
        //rightBtn(UIButton)/////////////////////////////////////////////
        self.rightBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        self.rightBtn.backgroundColor = [UIColor clearColor];
        self.rightBtn.frame = CGRectMake(self.frame.size.width - 45, 30, 25, 25) ;// (15,20,30,30)
        [self.rightBtn addTarget:self action:@selector(rightBtnClick) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:self.rightBtn];
        
        
        //label(UILabel)///////////////////////////////////////
        self.label = [[UILabel alloc]init];
        self.label.textAlignment = NSTextAlignmentCenter;
        self.label.font = [UIFont systemFontOfSize:NavigationBarFontSize];
        
        [self addSubview:self.label];
        
        
        ////////////////////////////////////////////////////////////////////
        self.backgroundColor = [UIColor clearColor];
        
        
    }
    return  self;

}


//setget

#pragma mark set左侧按钮图标
-(void)setBackTitleImage:(NSString *)backTitleImage{
    
    _backTitleImage = backTitleImage;
    [self.backBtn setImage:[UIImage imageNamed:_backTitleImage] forState:UIControlStateNormal];

}


#pragma mark set左侧按钮图标
-(void)setRightImageView:(NSString *)rightImageView{
    
    _rightImageView = rightImageView;
    [self.rightBtn setImage:[UIImage imageNamed:_rightImageView] forState:UIControlStateNormal];
    
}



#pragma mark set右侧按钮图标
-(void)setRightTitleImage:(NSString *)rightImageView{
    
    _rightImageView = rightImageView;
    [self.rightBtn setImage:[UIImage imageNamed:_rightImageView] forState:UIControlStateNormal];

}

-(void)setNameTitle:(NSString *)nameTitle{
    
    _nameTitle = nameTitle;
    self.label.text = _nameTitle;
    [_label sizeToFit];
    CGFloat titleLabCenterX = TheDeviceWidth/2;
    CGFloat titleLabCneterY = 40;
    _label.center = CGPointMake(titleLabCenterX, titleLabCneterY);
    
}



-(void)setColor:(UIColor *)color{
    
    _color = color;
    self.label.textColor = color;

}


//返回按钮

-(void)backBtnClick{
    
    if ([_delegate respondsToSelector:@selector(NavHeadToLeft)]) {
        [_delegate NavHeadToLeft];
    }

}

//右边按钮
-(void)rightBtnClick{
    
    if ([_delegate respondsToSelector:@selector(NavHeadToRight)]) {
        [_delegate NavHeadToRight];
        
    }
}

//渐变
-(void)jianBian{
    
    CAGradientLayer *gradientLayer = [CAGradientLayer layer];
    
    gradientLayer.frame = self.label.frame;
    gradientLayer.colors = @[(id)[UIColor colorWithRed:222/255.0 green:98/255.0 blue:26/255.0 alpha:0.1].CGColor, (id)[UIColor colorWithRed:245/255.0 green:163/255.0 blue:17/255.0 alpha:1].CGColor ];
    
    gradientLayer.mask = self.label.layer;
    [self.layer addSublayer:gradientLayer];
    self.label.frame = gradientLayer.bounds;
    
    
}




@end
