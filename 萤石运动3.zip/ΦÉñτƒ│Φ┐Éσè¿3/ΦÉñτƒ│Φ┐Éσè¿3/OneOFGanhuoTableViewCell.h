//
//  OneOFGanhuoTableViewCell.h
//  萤石运动3
//
//  Created by Winner Zhu on 16/8/17.
//  Copyright © 2016年 Winner Zhu. All rights reserved.
//

#import <UIKit/UIKit.h>

@class Ganhuo;

@interface OneOFGanhuoTableViewCell : UITableViewCell

#pragma mark 单元格高度
@property (nonatomic,assign) CGFloat Height;


#pragma mark Ganhuo对象
@property (nonatomic,strong) Ganhuo *ganhuo;

#pragma mark 定义一个lab容器
@property (nonatomic,strong) UIView *labContainer;

#pragma mark 定义Ganhuo显示区域
@property (nonatomic,strong) UILabel *DescriptionLabel;


























@end
