//
//  JSONModel.h
//  LearningParserHTML
//
//  Created by Winner Zhu on 2016/11/27.
//  Copyright © 2016年 Winner Zhu. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface JSONModel : NSObject

/*
 *1.get JSON model Fr network
 *2.push data to UICollecitonCell (data include)
 *3.the data in 2 is model that include imageUrl *1 and many string that parser from html //
 *4.the model in 3 add to a NSMutableArray
 *5.use the NSMutableArray in cellForItemInUICollection
 *6.get imageUrl *1 and many string and save it in a NSMutbaleDictionary √
 *7.so many string get Fr html, select n(number) save
 */

#pragma mark - 1
@property (nonatomic,strong) NSString *_id;

#pragma mark - 2
@property (nonatomic,strong) NSString *content;

#pragma mark - 3
@property (nonatomic,strong) NSString *created_at;

#pragma mark - 4
@property (nonatomic,strong) NSString *publishedAt;

#pragma mark - 5
@property (nonatomic,strong) NSString *rand_id;

#pragma mark - 6
@property (nonatomic,strong) NSString *title;

#pragma mark - 7
@property (nonatomic,strong) NSString *updated_at;



@end
