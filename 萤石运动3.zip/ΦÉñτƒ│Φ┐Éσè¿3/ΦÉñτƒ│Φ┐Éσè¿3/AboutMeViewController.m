//
//  AboutMeViewController.m
//  萤石运动3
//
//  Created by Winner Zhu on 2016/12/19.
//  Copyright © 2016年 Winner Zhu. All rights reserved.
//

#import "AboutMeViewController.h"
#import "NavHeadTitleView.h"
#import "Masonry.h"
#import "ShowGanhuoViewController.h"



#define TheDeviceWidth ([UIScreen mainScreen].bounds.size.width)
#define TheDeviceHeight ([UIScreen mainScreen].bounds.size.height)
#define TheHeightOFcustomNavBar 64
#define aboutMeVerticalControlSpacing 20  //纵向控件间距
#define aboutMeHorizontalControlSpacing 20  //横向控件间距
#define TheFontSizeOfDescription 14 
#define TheFontSizeOfversion 11
#define TheTextDoveGrayColor [UIColor colorWithRed:113.0/255.0 green:113.0/255.0 blue:113.0/255.0 alpha:255.0/255.0]


@interface AboutMeViewController ()

@end

@implementation AboutMeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    //0.设置UINivagationBar
    self.navigationController.navigationBar.hidden = YES;
    self.view.backgroundColor = [UIColor whiteColor];
    
    //2.createUINivagationBar
    [self createNav];
    
    //1.initSubViews
    [self initSubViews];
    
    
    //3.右滑返回效果
    //UIBarButtonItem *backItem;※if中的内容是右滑返回的关键;self.navigationItem.leftBarButtonItem是否设置都不重要;
    
    if ([[[UIDevice currentDevice]systemVersion] floatValue] >= 7.0 ) {
        
        self.navigationController.interactivePopGestureRecognizer.enabled = YES;
        //self.navigationController.interactivePopGestureRecognizer.delegate = self;
    }
    //self.navigationItem.leftBarButtonItem = backItem;
    
    
}


-(void)initSubViews{
    
    //0.icon ImageView
    iconImageView = [[UIImageView alloc]init];
    UIImage *iconImage = [UIImage imageNamed:@"60.png"];
    CGFloat iconWidth = iconImage.size.width;
    CGFloat iconHeight = iconImage.size.height;
    CGSize iconImageViewSize = CGSizeMake(iconWidth, iconHeight); //iconImageView由iconImage决定
    
    [self.view addSubview:iconImageView];
    [iconImageView mas_makeConstraints:^(MASConstraintMaker *iconImageViewMake){
       
        iconImageViewMake.size.mas_equalTo(iconImageViewSize);
        iconImageViewMake.top.equalTo(self.NavView.mas_bottom).offset(aboutMeHorizontalControlSpacing);
        iconImageViewMake.left.equalTo(self.view.mas_left).offset(aboutMeHorizontalControlSpacing);
        
    }];
    
    iconImageView.image = iconImage;
    
    
    //1.lineView
    lineView = [[UIView alloc]init];
    CGSize lineViewSize = CGSizeMake(TheDeviceWidth-aboutMeHorizontalControlSpacing*2, 0.6);
    lineView.backgroundColor = [UIColor colorWithRed:238.0/255.0 green:238.0/255.0 blue:238.0/255.0 alpha:255.0/255.0];
    
    [self.view addSubview:lineView];
    [lineView mas_makeConstraints:^(MASConstraintMaker *lineViewMake){
       
        lineViewMake.size.mas_equalTo(lineViewSize);
        lineViewMake.top.equalTo(iconImageView.mas_bottom).offset(aboutMeHorizontalControlSpacing/2);
        lineViewMake.left.equalTo(iconImageView.mas_left);
    }];
    
    
    //2.versonLab
    versionLab = [[UILabel alloc]init];
    versionLab.text = @"版本号：V0.0.1";
    versionLab.font = [UIFont systemFontOfSize:TheFontSizeOfversion];
    versionLab.textColor = TheTextDoveGrayColor;
    [versionLab sizeToFit];
    
    [self.view addSubview:versionLab];
    [versionLab mas_makeConstraints:^(MASConstraintMaker *versonLabMake){
        
        versonLabMake.left.equalTo(iconImageView.mas_right).offset(aboutMeHorizontalControlSpacing*2);
        versonLabMake.centerY.mas_equalTo(iconImageView.mas_centerY);
    }];
    
    
    //3.descLab
    descLab = [[UILabel alloc]init];
    descLab.text = @"技术干货和妹子图片来自代码家的干货集中营，每日干货集中营会分享漂亮妹子图和技术干货，还有供大家中午休息的休闲娱乐视频。在这里你可以一边看漂亮妹纸，一边学习技术提升自己。劳逸结合，效率高。小伙伴，你懂我的。";
    descLab.font = [UIFont systemFontOfSize:TheFontSizeOfDescription];
    descLab.textColor = TheTextDoveGrayColor;
    descLab.numberOfLines = 0;
    [descLab sizeToFit];
    
    [self.view addSubview:descLab];
    [descLab mas_makeConstraints:^(MASConstraintMaker *descLabMake){
       
        descLabMake.top.equalTo(lineView.mas_bottom).offset(aboutMeHorizontalControlSpacing/2);
        descLabMake.right.equalTo(lineView.mas_right);
        descLabMake.left.equalTo(lineView.mas_left);
        
    }];
    
    
    //4.lineView1
    lineView1 = [[UIView alloc]init];
    lineView1.backgroundColor = [UIColor colorWithRed:238.0/255.0 green:238.0/255.0 blue:238.0/255.0 alpha:255.0/255.0];
    
    [self.view addSubview:lineView1];
    [lineView1 mas_makeConstraints:^(MASConstraintMaker *lineView1Make){
        lineView1Make.size.mas_equalTo(lineViewSize);
        lineView1Make.top.equalTo(descLab.mas_bottom).offset(aboutMeHorizontalControlSpacing/2);
        lineView1Make.left.equalTo(descLab.mas_left);
        
    }];
    
    
    //5.aboutMeLab
    aboutMeLab = [[UILabel alloc]init];
    aboutMeLab.text = @"在这里花一些篇幅讲讲这个APP的开发者，你有木有觉得这个APP还是蛮不错的，但开发者并不是个全职iOS程序猿哦。本宝宝只是特别迷恋互联网行业，所以自学iOS开发。该APP是本宝第一个发布上线的产品，宝宝以后还会再接再厉开发更多更加精美的APP。么么哒！";
    aboutMeLab.font = [UIFont systemFontOfSize:TheFontSizeOfDescription];
    aboutMeLab.textColor = TheTextDoveGrayColor;
    aboutMeLab.numberOfLines = 0;
    [aboutMeLab sizeToFit];
    
    [self.view addSubview:aboutMeLab];
    [aboutMeLab mas_makeConstraints:^(MASConstraintMaker *aboutMeMake){
       
        aboutMeMake.top.equalTo(lineView1.mas_bottom).offset(aboutMeHorizontalControlSpacing/2);
        aboutMeMake.right.equalTo(lineView1.mas_right);
        aboutMeMake.left.equalTo(lineView1.mas_left);
    }];
    
    
    //6.lineView2
    lineView2 = [[UIView alloc]init];
    lineView2.backgroundColor = [UIColor colorWithRed:238.0/255.0 green:238.0/255.0 blue:238.0/255.0 alpha:255.0/255.0];
    
    [self.view addSubview:lineView2];
    [lineView2 mas_makeConstraints:^(MASConstraintMaker *lineView2Make){
        lineView2Make.size.mas_equalTo(lineViewSize);
        lineView2Make.top.equalTo(aboutMeLab.mas_bottom).offset(aboutMeHorizontalControlSpacing/2);
        lineView2Make.left.equalTo(aboutMeLab.mas_left);
        
    }];
    
    
    //7.linkLab
    linkLab = [[UILabel alloc]init];
    linkLab.text = @"友情链接";
    linkLab.font = [UIFont systemFontOfSize:TheFontSizeOfDescription];
    linkLab.textColor = TheTextDoveGrayColor;
    [linkLab sizeToFit];
    
    [self.view addSubview:linkLab];
    [linkLab mas_makeConstraints:^(MASConstraintMaker *linkLabMake){
        
        linkLabMake.top.equalTo(lineView2.mas_bottom).offset(aboutMeHorizontalControlSpacing/2);
        linkLabMake.left.equalTo(lineView2.mas_left);
    }];
    
    
    //8.linkBtn
    linkBtn = [[UIButton alloc]init];
    [linkBtn setTitle:@"项目GitHub地址" forState:UIControlStateNormal];
    [linkBtn setTitleColor:TheTextDoveGrayColor forState:UIControlStateNormal];
    linkBtn.titleLabel.font = [UIFont systemFontOfSize:TheFontSizeOfDescription];
    [linkBtn addTarget:self action:@selector(clickLinkBtn) forControlEvents:UIControlEventTouchUpInside];
   
    [self.view addSubview:linkBtn];
    [linkBtn mas_makeConstraints:^(MASConstraintMaker *linkBtnMake){
       
        linkBtnMake.top.equalTo(linkLab.mas_top);
        linkBtnMake.left.equalTo(versionLab.mas_left);
        linkBtnMake.bottom.equalTo(linkLab.mas_bottom);
    }];
    
    
    
    
}

-(void)createNav{
    
    self.NavView = [[NavHeadTitleView alloc]initWithFrame:CGRectMake(0, 0, TheDeviceWidth,TheHeightOFcustomNavBar)];
    self.NavView.nameTitle = @"关于";
    self.NavView.color = [UIColor blackColor];
    self.NavView.backTitleImage = @"backhome24w.png";
    self.NavView.rightTitleImage = @"";
    self.NavView.delegate = self;
    [self.view addSubview:self.NavView];
    
}

-(void)NavHeadToLeft{
    
    [self.navigationController popViewControllerAnimated:YES];
}

-(void)NavHeadToRight{
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


-(void)clickLinkBtn{
    
    ShowGanhuoViewController *showProjectInGithub = [[ShowGanhuoViewController alloc]init];
    NSString *gitHubUrl = @"http://www.cnblogs.com/kenshincui/p/3931948.html#uiTableViewCell";
    NSString *gitHubDesc = @"项目GitHub地址";
    
    Ganhuo *oneGanhuo = [[Ganhuo alloc]init];
    oneGanhuo.url = gitHubUrl;
    oneGanhuo.desc = gitHubDesc;
    
    showProjectInGithub.ganhuo = oneGanhuo;
    
    [self.navigationController pushViewController:showProjectInGithub animated:YES];
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
