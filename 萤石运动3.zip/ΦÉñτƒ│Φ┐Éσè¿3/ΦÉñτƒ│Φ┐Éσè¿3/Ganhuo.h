//
//  Ganhuo.h
//  萤石运动3
//
//  Created by Winner Zhu on 16/8/16.
//  Copyright © 2016年 Winner Zhu. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface Ganhuo : NSObject

//1
@property (nonatomic,strong) NSString *_id;  //一串数字

//2
@property (nonatomic,strong) NSString *createdAt;  //时间

//3
@property (nonatomic,strong) NSString *desc;

//4
@property (nonatomic,strong) NSString *publishedAt; //时间

//5
@property (nonatomic,strong) NSString *type;

//6
@property (nonatomic,strong) NSString *url;

//7
@property (nonatomic,strong) NSString *used;

//8
@property (nonatomic,strong) NSString *who;

//9 16.11.17添加
@property (nonatomic,strong) NSString *source;

//10 16.11.17添加
@property (nonatomic,strong) NSString *images;





/*
9
"_id": "57ac1342421aa949ef961f3f",
"createdAt": "2016-08-11T13:55:14.853Z",
"desc": "\u5b9e\u73b0\u52a8\u6001\u6a21\u7cca",
"publishedAt": "2016-08-12T11:39:10.578Z",
"source": "web",
"type": "Android",
"url": "http://blog.csdn.net/wl9739/article/details/51955598",
"used": true,
"who": null
 
 10
 "_id": "57ac175e421aa94a0226e654",
 "createdAt": "2016-08-11T14:12:46.69Z",
 "desc": "\u6e05\u695a\u660e\u4e86\u7684\u81ea\u5b9a\u4e49View\u6d41\u7a0b",
 "images": [
 "http://upload-images.jianshu.io/upload_images/1336465-ff9f93d22ef1f6cd?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240",
 "http://upload-images.jianshu.io/upload_images/1336465-b963069f199c5bb3?imageMogr2/auto-orient/strip"
 ],
 "publishedAt": "2016-08-12T11:39:10.578Z",
 "source": "chrome",
 "type": "Android",
 "url": "http://www.jianshu.com/p/86e867b9bee8",
 "used": true,
 "who": "\u6253\u54c8\u54c8"
 
*/






@end
