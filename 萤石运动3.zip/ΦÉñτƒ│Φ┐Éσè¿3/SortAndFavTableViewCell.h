//
//  SortAndFavTableViewCell.h
//  萤石运动3
//
//  Created by Winner Zhu on 2016/11/9.
//  Copyright © 2016年 Winner Zhu. All rights reserved.
//

#import <UIKit/UIKit.h>


@class FavouriteGanhuo; 


@interface SortAndFavTableViewCell : UITableViewCell


#pragma mark 定义ganhuo的desc显示区域
@property (nonatomic,strong) UILabel *DescriptionLabel;

#pragma mark 设置单元格高度
@property (nonatomic,assign) CGFloat Height;

#pragma mark FavGanhuo对象
@property (nonatomic,strong) FavouriteGanhuo *SortAndFavGanhuo;



@end
