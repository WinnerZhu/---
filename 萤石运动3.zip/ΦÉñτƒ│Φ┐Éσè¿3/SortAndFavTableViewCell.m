//
//  SortAndFavTableViewCell.m
//  萤石运动3
//
//  Created by Winner Zhu on 2016/11/9.
//  Copyright © 2016年 Winner Zhu. All rights reserved.
//

#import "SortAndFavTableViewCell.h"
#import "FavouriteGanhuo.h"

#define AnyColor(r,g,b) [UIColor colorWithHue:r/255.0 saturation:g/255.0 brightness:b/255.0 alpha:1]
#define TableViewCellBackgroundColor AnyColor(251,251,251)
#define TableViewCellLightGrayColor AnyColor(120,120,120)
#define TableViewCellDoveGrayColor [UIColor colorWithRed:113.0/255.0 green:113.0/255.0 blue:113.0/255.0 alpha:255.0/255.0]

#define OneOFGanhuoTabCellDescriptionFontSize 14    //description字体
#define OneOFGanhuoTabCellVerticalControlSpacing 15  //纵向控件间距
#define OneOFGanhuoTabCellHorizontalControlSpacing 15  //横向控件间距

#define TheDeviceWidth ([UIScreen mainScreen].bounds.size.width)
#define TheDeviceHeight ([UIScreen mainScreen].bounds.size.height)


@implementation SortAndFavTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}



- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}




#pragma mark 初始化UITableViewCell
-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self initSubView];
    }
    return self;
    
}



#pragma mark LayOutUI
-(void)initSubView{
    
    _DescriptionLabel = [[UILabel alloc]init];
    _DescriptionLabel.textColor = TableViewCellDoveGrayColor;
    _DescriptionLabel.font = [UIFont systemFontOfSize:OneOFGanhuoTabCellDescriptionFontSize];
    _DescriptionLabel.numberOfLines = 0;
    
    UIView *lineView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, TheDeviceWidth, 0.5)];
    lineView.backgroundColor = [UIColor colorWithRed:238.0/255.0 green:238.0/255.0 blue:238.0/255.0 alpha:255.0/255.0];//[UIColor lightGrayColor];
    
    [self.contentView addSubview:lineView];
    [self.contentView addSubview:_DescriptionLabel];
    
}



#pragma mark 设置干货
-(void)setSortAndFavGanhuo:(FavouriteGanhuo *)SortAndFavGanhuo{
    
    //设置Description位置
    CGFloat DescLabelX = OneOFGanhuoTabCellHorizontalControlSpacing;
    CGFloat DescLabelY = OneOFGanhuoTabCellVerticalControlSpacing;
    CGFloat DescLabelWitdth = TheDeviceWidth - OneOFGanhuoTabCellHorizontalControlSpacing*2;

    
    CGSize DescLabelSize = [SortAndFavGanhuo.favganhuodesc boundingRectWithSize:CGSizeMake(DescLabelWitdth, MAXFLOAT) options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName: [UIFont systemFontOfSize:OneOFGanhuoTabCellDescriptionFontSize]} context:nil].size;
    
    CGRect DescLabelRect = CGRectMake(DescLabelX, DescLabelY, DescLabelSize.width, DescLabelSize.height);
    _DescriptionLabel.frame = DescLabelRect;
    _DescriptionLabel.text = SortAndFavGanhuo.favganhuodesc;
    
    _Height = CGRectGetMaxY(_DescriptionLabel.frame)+OneOFGanhuoTabCellVerticalControlSpacing;
    
}






@end
